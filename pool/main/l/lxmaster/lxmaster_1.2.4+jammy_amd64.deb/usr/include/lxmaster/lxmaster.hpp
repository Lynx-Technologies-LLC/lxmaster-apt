#pragma once

/**
 * @file lxmaster/lxmaster.hpp
 * @brief Single public entry point for LXMASTER consumers.
 *
 * Include this one header to access the full application API through the flat
 * `lxmaster::` namespace. No other header needs to be included for typical
 * control applications.
 *
 * This header re-exports the core types from their implementation namespaces:
 * - `ecnet::` — network facade and configuration (`EcNetwork`, `NetworkConfig`, …)
 * - `ecfacade::` — device handles (`Axis`, `IoModule`, `Encoder`, `GenericDevice`)
 * - `ecdev::` — drive operating modes (`DriveOpMode`)
 *
 * Example:
 * @code
 * #include <lxmaster/lxmaster.hpp>
 *
 * lxmaster::NetworkConfig cfg = lxmaster::NetworkConfig::defaults();
 * cfg.eni.eni_path = "network.eni.xml";
 * lxmaster::EcNetwork net(cfg);
 * if (!net.start()) { std::cerr << net.lastError(); return 1; }
 * lxmaster::Axis* axis = net.axes().front();
 * axis->enable();
 * axis->moveTo(0);
 * @endcode
 *
 * @ingroup application_api
 */
#include "ecnet/bus_fault.hpp"
#include "ecnet/ec_network.hpp"

/**
 * @namespace lxmaster
 * @brief Flat public namespace for LXMASTER consumers.
 *
 * All types needed by a control application are aliased here so that user code
 * only depends on the `lxmaster::` prefix and never on the internal namespaces
 * (`ecnet`, `ecfacade`, `ecdev`).
 */
namespace lxmaster {

/** @name Network facade and configuration */
///@{
using ecnet::EcNetwork;
using ecnet::NetworkConfig;
using ecnet::SyncMode;
///@}

/** @name Diagnostics surfaced by EcNetwork */
///@{
using ecnet::BusFault;
using ecnet::LostSlave;
using ecnet::SyncTracePhase;
using ecnet::SyncTraceSample;
///@}

/** @name Device handles returned by EcNetwork */
///@{
using ecfacade::Axis;
using ecfacade::Encoder;
using ecfacade::GenericDevice;
using ecfacade::IoModule;
///@}

/** @name Drive operating modes */
///@{
using ecdev::DriveOpMode;
///@}

}  // namespace lxmaster
