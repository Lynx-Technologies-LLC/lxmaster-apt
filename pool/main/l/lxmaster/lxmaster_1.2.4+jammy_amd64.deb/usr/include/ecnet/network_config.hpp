#pragma once

#include "devices/log.hpp"
#include "devices/profile_registry.hpp"
#include "devices/sync_mode.hpp"

#include "ecmaster/ec_master.hpp"
#include "ecnet/bus_fault.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace ecnet {

/** Re-exported here so callers only need `ecnet/network_config.hpp`. */
using SyncMode = ecdev::SyncMode;

/** Pass to `DcConfig::dc_sync_busy_wait_ns` to use `bus.cycle_ns / 4`. */
static constexpr std::int32_t kDcSyncBusyWaitAuto = -1;

/**
 * Low-level EtherCAT bus parameters. Most fields are resolved from the ENI and are read-only
 * from the application's perspective; `ifname` is the only field that must be supplied by the
 * application (or read from the `LXMASTER_RT_IFACE` environment variable by `NetworkConfig::defaults()`).
 */
struct BusConfig {
  /** Name of the network interface to use as the EtherCAT master port (e.g. `"eth0"`, `"enp3s0"`).
   *  Set explicitly or rely on `NetworkConfig::defaults()` to read `LXMASTER_RT_IFACE`. */
  std::string ifname;
  /** Cyclic period in ns. 0 = unset until the ENI is loaded; `EcNetwork` adopts the ENI's
   *  `<Config><Cyclic><CycleTime>` as the single source of truth. There is no CLI/code override. */
  std::uint32_t cycle_ns{0};
  /** Resolved output, not an input: `EcNetwork::loadAndValidateEni` sets this from the ENI
   *  (DcSync0 when the bus carries a SYNC0 device, else SmEvent). The app does not choose it. */
  SyncMode sync_mode{SyncMode::DcSync0};
};

/**
 * Distributed-clocks (DC) and SYNC0 configuration. The ENI is the authority on whether DC is
 * used at all: `EcNetwork` derives `use_dc` and `use_sync0` from whether the ENI carries
 * per-slave `<DC>` blocks. The SYNC0 period and phase-shift come from each slave's `<DC>`
 * (`CycleTime0` / `ShiftTime`). The tunable fields below govern the PI synchronisation
 * controller and the OP-entry gate; see `NetworkConfig::defaults()` for the environment
 * variable overrides.
 */
struct DcConfig {
  /** Whether distributed clocks are enabled. Derived from the ENI; not a user-settable policy. */
  bool use_dc{true};
  /** Whether SYNC0 pulses are activated per-slave. Derived from the ENI; not a user-settable policy. */
  bool use_sync0{true};
  /** When true the master synchronises its cyclic wakeup to the reference-slave DC clock using the
   *  `ecSyncToDc` PI controller. When false the master runs free (fixed-period timer). Overridable
   *  via `LXMASTER_EC_SYNC_TO_DC`. */
  bool ec_sync_to_dc{true};
  /** Proportional gain divisor of the DC-sync PI controller. The effective Kp = 1 / dc_sync_kp_div.
   *  Larger values damp the proportional response; default 3. Overridable via `LXMASTER_DC_SYNC_KP_DIV`. */
  std::int32_t dc_sync_kp_div{3};
  /** Integral gain divisor of the DC-sync PI controller. The effective Ki = 1 / dc_sync_ki_div.
   *  Larger values slow the integrator wind-up; default 20. Overridable via `LXMASTER_DC_SYNC_KI_DIV`. */
  std::int32_t dc_sync_ki_div{20};
  /** Busy-wait spin duration (ns) inside `ecSyncToDc` to absorb the final sub-cycle slack after the
   *  timer fires. `kDcSyncBusyWaitAuto` (−1) selects `cycle_ns / 4` at runtime. Tuning this reduces
   *  the DC alignment error on systems with coarse timer resolution. Overridable via
   *  `LXMASTER_DC_SYNC_BUSY_WAIT_NS`. */
  std::int32_t dc_sync_busy_wait_ns{kDcSyncBusyWaitAuto};
  /** When true, the sync-trace ring also records samples from the `Warmup` and `DcGate` phases
   *  (pre-operational). Default false — trace starts at `Operational`. */
  bool sync_trace_include_warmup{false};
  /** Number of RT cycles to run in `Warmup` phase before attempting OP entry, giving the DC PI
   *  controller time to converge. Overridable via `LXMASTER_DC_LOCK_WARMUP_CYCLES`. */
  int dc_lock_warmup_cycles{200};
  /** Maximum allowed `|dc_delta|` (ns) for the DC gate to consider the bus aligned. The gate counts
   *  consecutive cycles below this threshold before allowing OP entry. Overridable via
   *  `LXMASTER_DC_DIFF_OP_GATE_MAX_NS`. */
  std::uint32_t dc_diff_op_gate_max_ns{10'000};
  /** Number of consecutive cycles that must satisfy `|dc_delta| < dc_diff_op_gate_max_ns` before
   *  the OP-entry gate opens. Overridable via `LXMASTER_DC_DIFF_OP_GATE_STABLE_CYCLES`. */
  int dc_diff_op_gate_stable_cycles{40};
  /** Timeout for the DC alignment gate (cycles). If alignment is not achieved within this many
   *  cycles, bring-up fails with a clear error. Overridable via
   *  `LXMASTER_DC_DIFF_OP_GATE_TIMEOUT_CYCLES`. */
  int dc_diff_op_gate_timeout_cycles{2'000};
};

/**
 * Real-time scheduling settings applied to the cyclic RT thread before `start()` enters the bus
 * bring-up. All fields are overridable via environment variables (see `NetworkConfig::defaults()`).
 */
struct RtConfig {
  /** When true the cyclic thread is set to `SCHED_FIFO` before the bus runs. Set false for
   *  non-RT hosts (stock kernel, development machines). Overridable via `LXMASTER_RT_ENABLE`. */
  bool enable_rt_scheduling{true};
  /** `SCHED_FIFO` priority for the cyclic thread (1–99). 49 leaves headroom above interrupt
   *  threads while staying below the watchdog. Overridable via `LXMASTER_RT_PRIORITY`. */
  int rt_priority{49};
  /** CPU core to pin the cyclic thread to (0-based index). -1 = no affinity (OS scheduler
   *  decides). Pin to an isolated core for best jitter on PREEMPT_RT. Overridable via
   *  `LXMASTER_RT_CPU`. */
  int cpu_affinity{-1};
};

/**
 * Runtime logging and diagnostic capture configuration. Logging is off by default
 * (`enabled == false`) to preserve a quiet runtime. When enabled, severity and subsystem
 * filtering are controlled by `min_level` and `category_mask`. The compile-time
 * `LXMASTER_ENABLE_DEBUG` flag strips `Info`/`Debug`/`Trace` call sites from release builds;
 * `Error` and `Warn` are always compiled in.
 */
struct DebugConfig {
  /** Master switch for runtime logging. When false (default) nothing is emitted and all other
   *  fields in this struct are ignored. */
  bool enabled{false};
  /** Minimum log severity to emit. Messages below this level are silently dropped. Has no effect
   *  when `enabled == false`. */
  ecdev::LogLevel min_level{ecdev::LogLevel::Info};
  /** Bitmask selecting which log categories to emit (see `ecdev::LogCategory`). Default
   *  `kLogCatAll` passes every category. Has no effect when `enabled == false`. */
  std::uint32_t category_mask{ecdev::kLogCatAll};
  /** Log destination. Empty (default) = `ConsoleSink` (stderr for Error/Warn, stdout otherwise);
   *  non-empty path = rotating `FileSink` writing to that file. */
  std::string log_file;
  /** Capacity (in entries) of the lock-free ring buffer used to hand process-data snapshots
   *  from the RT thread to the background logger worker. Must be a power of two; 0 = built-in
   *  default. Increase when high-rate `Trace` logging drops entries. */
  std::size_t debug_ring_capacity{0};
  /** Number of per-cycle `SyncTraceSample` slots in the executor's sync-trace ring buffer.
   *  0 (default) disables sync tracing. When non-zero the ring captures every cycle and wraps;
   *  `EcNetwork::syncTraceReport()` returns the final contents after `stop()`. */
  std::size_t sync_trace_capacity{0};
  /** DC alignment violation threshold (ns). When non-zero, cycles where `|dc_delta_ns|` exceeds
   *  this value are counted in `SyncTraceReport::violation_count` and flagged in the live
   *  `syncTraceViolationCount()` counter. 0 = no violation tracking. */
  std::uint32_t sync_trace_window_ns{0};
};

/**
 * Timeouts (in milliseconds) for the ordered shutdown sequence that `stop()` executes after
 * joining the RT thread. The sequence walks the bus from OPERATIONAL back through SAFE_OP and
 * PRE_OP before closing the NIC.
 */
struct ShutdownConfig {
  /** Maximum time to wait for all devices to reach their per-device shutdown resting state
   *  (e.g. a CiA402 drive reaching Switch-On Disabled) after the cyclic thread has stopped. */
  int device_timeout_ms{500};
  /** Maximum time to wait for all slaves to acknowledge the SAFE_OP state transition request
   *  via the AL-status gate. */
  int al_gate_timeout_ms{2000};
  /** Settle time (ms) after the synchronised outputs are disabled (SOD) before continuing
   *  the state walk-down. Allows drives to coast to rest before PreOp. */
  int post_sod_settle_ms{200};
  /** Maximum time to wait for all slaves to reach SAFE_OP during the shutdown walk-down. */
  int safeop_timeout_ms{2000};
  /** Maximum time to wait for each individual AL state transition during shutdown. */
  int al_state_timeout_ms{2000};
};

/**
 * ENI-driven configuration. `EcNetwork` loads `eni_path` (required), validates it against the
 * project-bundled ETG.2100 schema (embedded — there is no user-supplied XSD), verifies it
 * matches the scanned hardware, and auto-creates one device per ENI `<Slave>`.
 * ENI is the only setup mode: there is no code-first / hard-coded device path.
 *
 * Per-axis settings (operating mode, fault policy) are applied after `prepare()` returns by
 * iterating `net.axes()` and calling `Axis::setDriveMode()` before `start()`.
 */
struct EniConfig {
  /** Path to the EtherCAT Network Information (ENI) file (ETG.2100 XML). Required — `start()`
   *  fails immediately if this is empty or the file cannot be read. */
  std::string eni_path;
};

/**
 * User-facing configuration for an EcNetwork. Bus timing, DC, RT scheduling, and shutdown
 * policy live here; drive-specific PDO/FSM options live on `CiA402Config` / vendor configs.
 *
 * Deployment RT overrides: `scripts/rt/README.md`.
 */
struct NetworkConfig {
  static constexpr std::int32_t kDcSyncBusyWaitAuto = ecnet::kDcSyncBusyWaitAuto;

  BusConfig bus;
  DcConfig dc;
  RtConfig rt;
  DebugConfig debug;
  ShutdownConfig shutdown;
  EniConfig eni;
  /** Backend protocol timeouts / retries (microseconds). Defaults from the backend baseline;
   *  overridable via `LXMASTER_TIMEOUT_*` / `LXMASTER_RETRIES`. Pushed to the backend before `init()`
   *  (honored on a best-effort basis depending on the active backend). */
  ecmaster::Timeouts timeouts;
  /** Number of consecutive cycles with a low work-counter (below expected) before the cycle-health
   *  watchdog trips and raises a `BusFault`. Increase for buses that tolerate occasional WKC drops
   *  without a real cable fault; decrease for faster fault detection. */
  int watchdog_low_wkc_cycles{100};
  /** Number of RT cycles to hold in the `Cooldown` phase after the master requests OPERATIONAL,
   *  before the executor starts processing normal motion commands. Gives drives time to settle
   *  their internal control loops after the OP transition. */
  int op_entry_cooldown_cycles{8};

  /**
   * Optional bus-fault notification. Invoked exactly once when the cycle-health watchdog trips
   * (a slave dropped out / cable unplugged / frames corrupted), carrying a structured `BusFault`
   * that pinpoints the break (upstream slave + ESC port) and lists the slaves that went silent.
   *
   * Delivery: called on a detached helper thread (NOT the RT cyclic thread), so the handler may
   * do non-RT work and may safely call `EcNetwork::stop()`. Because it runs detached, anything the
   * handler captures by reference must outlive the network. Leave empty to opt out; lxmaster still
   * renders the fault in `lastError()` / `reportDeviceStatus()`.
   */
  std::function<void(const BusFault&)> on_bus_fault;

  /**
   * Optional developer-session expiry notification. Invoked once when the 12-hour floating-seat
   * deadline is reached (only active on floating-seat / developer session types).
   *
   * Delivery: called on a dedicated, non-RT, non-CPU-affinitised watcher thread that blocks on a
   * `condition_variable::wait_until` (zero CPU during the run). The handler must NOT call
   * `EcNetwork::stop()` directly (that would deadlock on the watcher thread's own join). Instead,
   * set a flag that the main loop polls — for example:
   * @code
   *   cfg.on_session_expiry = []{ apps_common::interruptFlag().store(true,
   *                                   std::memory_order_release); };
   * @endcode
   * The main loop `while (net.isRunning() && !interrupted())` then exits and calls `net.stop()`.
   * Leave empty to opt out; the session deadline is still enforced (the watcher fires but the
   * callback is skipped — the RT thread continues until the main loop exits by another means).
   */
  std::function<void()> on_session_expiry;

  /**
   * App-supplied device classes, considered ahead of the self-registered built-ins when classifying
   * each ENI slave (see `ecdev::ProfileRegistry::select`). Use this to bind a device identity for a
   * single run without static registration -- e.g.
   * `cfg.extra_profile_factories.push_back(ecdev::makeIdentityProfileFactory({vendor, product},
   * makeMyProfile, "my-device"));`. `shared_ptr` keeps `NetworkConfig` copyable. The durable path
   * for a new device is still a self-registering file (LXMASTER_REGISTER_DEVICE).
   */
  std::vector<std::shared_ptr<ecdev::IProfileFactory>> extra_profile_factories;

  /** Network defaults (DC-sync PI kp_div=3, ki_div=20). The cyclic period is
   *  left unset (`bus.cycle_ns == 0`) and the sync mode is decided by the ENI in
   *  `EcNetwork::loadAndValidateEni`; the PI tuning here is inert when the ENI resolves to the SM
   *  event. There is no app-layer DC-vs-SM choice.
   *
   *  Host-side params are read here from the per-host `LXMASTER_*` environment (published by
   *  `/etc/profile.d/lxmaster-config.sh`; see `scripts/rt/README.md`), so the
   *  effective precedence is built-in default < ENV. The set covers the DC-sync
   *  PI knobs (kp_div, ki_div, dc_sync_busy_wait_ns, dc_lock_warmup_cycles, ec_sync_to_dc), the
   *  OP-entry DC gate (dc_diff_op_gate_max_ns / _stable_cycles / _timeout_cycles) and
   *  op_entry_cooldown_cycles, the RT scheduling identity (rt.cpu_affinity, rt.rt_priority,
   *  rt.enable_rt_scheduling), the EtherCAT interface name (`LXMASTER_RT_IFACE` -> `bus.ifname`), and
   *  the backend protocol timeouts/retries (`LXMASTER_TIMEOUT_*` / `LXMASTER_RETRIES` -> `timeouts.*`).
   *  Missing vars warn once and keep the built-in default (RT_ENABLE and the timeout knobs are
   *  silent opt-outs). */
  static NetworkConfig defaults();
};

/**
 * Execution phase tag recorded in each `SyncTraceSample`. The RT thread transitions through these
 * phases in order during a normal run. Phases before `Operational` are excluded from
 * `DcSyncStats` unless `DcConfig::sync_trace_include_warmup` is set.
 */
enum class SyncTracePhase : std::uint8_t {
  Warmup = 0,   ///< DC PI controller warming up (lock not yet acquired).
  DcGate = 1,   ///< Waiting for DC alignment to stabilise before requesting OP.
  Cooldown = 2, ///< OP-entry cooldown cycles after the master enters OPERATIONAL.
  Operational = 3, ///< Steady-state cyclic operation.
  Shutdown = 4, ///< RT thread is winding down (after stop request).
};

/**
 * Single per-cycle DC-sync and jitter capture point. Written to the executor's ring buffer each
 * cycle when `NetworkConfig::DebugConfig::sync_trace_capacity > 0`. The full ring is returned by
 * `EcNetwork::syncTraceReport()` after `stop()`.
 */
struct SyncTraceSample {
  /** Absolute RT-thread cycle counter (since `start()`). */
  std::uint64_t rt_cycle{0};
  /** Monotonically increasing counter of cycles spent in `Operational` phase (0 in earlier phases). */
  std::uint64_t operational_cycle_seq{0};
  /** Signed difference between the host wake time and the reference-slave DC reference time (ns).
   *  The quantity the PI controller drives toward zero. */
  std::int64_t dc_delta_ns{0};
  /** Signed jitter of this cycle's host wake relative to the ideal deadline (ns). */
  std::int64_t jitter_err_ns{0};
  /** Reference-slave DC clock reading captured this cycle (ns, raw 64-bit DC time). */
  std::int64_t dc_reftime_ns{0};
  /** Expected DC reference time for this cycle based on the nominal period (ns). */
  std::int64_t expected_dc_reftime_ns{0};
  /** PI integrator state at this cycle (ns). The steady-state value is the converged DC offset. */
  std::int64_t integral_ns{0};
  /** Time-offset correction (`toff`) applied to the master clock this cycle (ns). */
  std::int64_t toff_ns{0};
  /** Execution phase this cycle belonged to. */
  SyncTracePhase phase{SyncTracePhase::Operational};
};

}  // namespace ecnet
