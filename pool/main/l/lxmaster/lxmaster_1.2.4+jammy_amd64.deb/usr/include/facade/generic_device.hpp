#pragma once

#include "facade/device_facade.hpp"

namespace ecfacade {

/**
 * Application handle for a device whose profile implements none of the typed capability contracts
 * (not an {@link Axis}, {@link IoModule}, or {@link Encoder}) -- e.g. an EtherCAT IMU or any other
 * vendor device modelled by a custom {@link ecdev::IDeviceProfile}.
 *
 * It adds nothing beyond {@link DeviceFacade}: the generic device is reached via
 * `EcNetwork::devices()`, brought to OPERATIONAL with `configure()`, and its custom profile is
 * obtained with `deviceProfile()` (then recovered to the concrete profile type with a
 * `profileName()`-guarded `static_cast`, RTTI-free, once at setup -- see `deviceProfile()`). A device
 * that also exposes a typed capability still appears here in addition to its typed list, so
 * `devices()` is the complete set of profile-carrying slaves.
 */
class GenericDevice : public DeviceFacade {
public:
  using DeviceFacade::DeviceFacade;
};

}  // namespace ecfacade
