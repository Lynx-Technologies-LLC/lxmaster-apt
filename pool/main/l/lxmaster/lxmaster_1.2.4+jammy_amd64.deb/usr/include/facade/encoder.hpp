#pragma once

#include "devices/encoder_profile.hpp"
#include "facade/device_facade.hpp"

#include <cstdint>
#include <string>

namespace ecfacade {

/**
 * High-level encoder handle. Thin wrapper over an {@link ecdev::IEncoderProfile}; the application
 * reads position/velocity/status without seeing CoE objects or the backend.
 */
class Encoder : public DeviceFacade {
public:
  Encoder(ecdev::IEncoderProfile* enc, std::string name, ecdev::IEthercatDevice* device);

  /** Latest position reading from the sensor (encoder counts, CiA406 0x6004). RT-safe. */
  std::int32_t position() const noexcept;
  /** Latest velocity reading from the sensor (counts/s). Returns 0 if the device does not map
   *  a velocity object. RT-safe. */
  std::int32_t velocity() const noexcept;
  /** Raw operating-status word from the sensor. Returns 0 if the device does not map a status
   *  object. Consult the device datasheet for bit definitions. RT-safe. */
  std::uint16_t status() const noexcept;

  /** Escape hatch to the underlying encoder profile contract for callers that need capabilities
   *  beyond the standard position/velocity/status accessors.
   * @return The `IEncoderProfile` backing this encoder. Never null while the encoder is valid. */
  ecdev::IEncoderProfile* encoderProfile() const noexcept;

private:
  ecdev::IEncoderProfile* enc_;
};

}  // namespace ecfacade
