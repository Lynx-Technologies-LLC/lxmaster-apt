#pragma once

#include <cstdint>
#include <string>
#include <vector>

/**
 * Intermediate, master-agnostic model of an EtherCAT network configuration.
 *
 * It is the shared currency between two directions:
 *   - eni_gen (tool): merges a live SOEM scan with matched ESI metadata and
 *     serializes this model into an ETG.2100 EtherCATConfig (ENI).
 *   - eni_reader (runtime): parses a user-provided ENI back into this model so
 *     the runtime can build generic CiA402 devices without any vendor C++.
 *
 * Keeping the model independent of both SOEM and any XML library keeps the
 * merge/parse logic testable and the serializers free of discovery concerns.
 */
namespace eni {

/** One mapped object inside a PDO (e.g. 0x6040:0, Controlword, 16 bits, UINT). */
struct PdoEntry {
  std::uint16_t index{0};    ///< Object index; 0 denotes a padding/gap entry.
  std::uint8_t sub_index{0};
  std::uint8_t bit_len{0};
  std::string name;
  std::string data_type;     ///< ESI type token (UINT, DINT, ...); may be empty.
};

/** A process-data object (RxPdo/TxPdo) and its entry list. */
struct Pdo {
  std::uint16_t index{0};        ///< 0x1600.. (Rx) / 0x1A00.. (Tx).
  std::uint8_t sm{0};            ///< Sync manager this PDO is assigned to.
  bool is_tx{false};             ///< true = TxPdo (slave->master input).
  std::string name;
  bool fixed{false};
  bool mandatory{false};
  std::vector<PdoEntry> entries;
};

/** Sync manager configuration. SOEM SMtype: 0 unused,1 MbxWr,2 MbxRd,3 Out,4 In. */
struct SyncManager {
  std::uint8_t index{0};
  std::uint16_t start_address{0};
  std::uint8_t control_byte{0};
  std::uint16_t default_size{0};
  std::uint8_t type{0};
  bool enable{true};
};

/** Fieldbus Memory Management Unit record (logical <-> physical mapping). */
struct Fmmu {
  std::uint32_t log_start{0};
  std::uint16_t log_length{0};
  std::uint8_t log_start_bit{0};
  std::uint8_t log_end_bit{0};
  std::uint16_t phys_start{0};
  std::uint8_t phys_start_bit{0};
  std::uint8_t type{0};   ///< ESC FMMU type: 2 = outputs (write), 1 = inputs (read).
  bool active{false};
};

/** Mailbox window + supported protocols. */
struct Mailbox {
  std::uint16_t out_start{0};   ///< Master->slave SM start (SOEM mbx_wo).
  std::uint16_t out_size{0};    ///< SOEM mbx_l.
  std::uint16_t in_start{0};    ///< Slave->master SM start (SOEM mbx_ro).
  std::uint16_t in_size{0};     ///< SOEM mbx_rl.
  bool coe{false};
  bool eoe{false};
  bool foe{false};
  bool soe{false};
  bool aoe{false};
  bool voe{false};
  bool present() const { return out_size != 0 || in_size != 0; }
};

/** Distributed-clock configuration, primarily from the ESI OpMode. */
struct DcConfig {
  bool has_dc{false};
  bool active{false};
  std::string op_mode_name;
  std::uint16_t assign_activate{0};  ///< ESI <AssignActivate> (e.g. 0x300).
  std::uint32_t cycle_time0_ns{0};
  std::uint32_t cycle_time1_ns{0};
  std::int32_t shift_time0_ns{0};
  /** ETG.2100 <DC><PotentialReferenceClock>: this slave can be the DC reference clock. */
  bool potential_reference_clock{false};
  /** ETG.2100 <DC><ReferenceClock>: this slave is the bus reference clock (exactly one). */
  bool reference_clock{false};
};

/** A single ESM-transition init command (register write or CoE mailbox write). */
struct InitCmd {
  std::string transition;            ///< "IP","PS","SP","SO","PI","SI",...
  std::string comment;
  bool is_coe{false};                ///< true = CoE SDO write, false = register write.
  // Register form:
  std::uint16_t ado{0};              ///< Address offset (ESC register).
  /** true = broadcast write (BWR, Adp=0) addressed at every slave; false = configured-address
   *  write (FPWR) to one slave. Broadcasts carry BeforeSlave/Requires=cycle and belong to the
   *  master-level init list (the standard DC-reset sequence), not to a single <Slave>. */
  bool broadcast{false};
  /** When > 0 the command is serialized with <DataLength> (master zero-fills that many bytes)
   *  instead of an explicit <Data> payload. Used for the wide DC system-time clear. */
  std::uint16_t data_length_fill{0};
  // CoE form:
  std::uint16_t index{0};
  std::uint8_t sub_index{0};
  bool complete_access{false};
  // Common:
  std::vector<std::uint8_t> data;    ///< Payload bytes (little-endian as on the wire).

  // --- Extended ECatCmdType fields (full state-machine InitCmds, ETG.2100) ---
  /** Additional transitions beyond `transition`; when non-empty the command is emitted with one
   *  <Transition> per entry (a real state machine tags e.g. PI/BI/SI/OI on one command). */
  std::vector<std::string> transitions;
  /** Explicit EtherCAT command id (1=APRD, 2=APWR, 4=FPRD, 5=FPWR, 7=BRD, 8=BWR). 0 = let the
   *  serializer pick the legacy default (5 for a slave register write, 8 for a master broadcast). */
  std::uint8_t cmd_code{0};
  std::uint16_t adp{0};              ///< Address position (auto-increment or fixed station address).
  bool has_adp{false};               ///< true = emit `adp`; false = serializer default (phys/0).
  bool before_slave{false};          ///< emit <BeforeSlave>true</BeforeSlave>.
  bool requires_cycle{false};        ///< emit <Requires>cycle</Requires>.
  int cnt{-1};                       ///< expected working counter; <0 = omit <Cnt>.
  int retries{-1};                   ///< <Retries>; <0 = omit.
  std::uint32_t timeout{0};          ///< write <Timeout> ms; 0 = omit (ignored when validate set).
  std::vector<std::uint8_t> validate_data;  ///< <Validate><Data>; empty = no <Validate> block.
  std::vector<std::uint8_t> validate_mask;  ///< <Validate><DataMask> (optional).
  std::uint32_t validate_timeout{0};        ///< <Validate><Timeout> ms.
};

/** Everything needed to emit (or consume) one <Slave> element. */
struct SlaveConfig {
  int position{0};                   ///< 1-based bus position (SOEM index).
  std::string name;
  std::uint16_t phys_addr{0};        ///< Configured station address (SOEM configadr).
  std::int16_t auto_inc_addr{0};     ///< 0, -1, -2, ... = 0 - (position-1).
  std::uint16_t alias{0};
  std::uint32_t vendor_id{0};
  std::uint32_t product_code{0};
  std::uint32_t revision{0};
  std::uint32_t serial{0};
  /** CANopen profile number (ESI <Profile><ProfileNo>): 402 drive, 401 I/O, 406 encoder, 5001
   *  modular, etc. 0 = absent. Used as the family-fallback classification tier when no device-class
   *  identity matches. */
  std::uint32_t profile_no{0};
  std::string physics;               ///< e.g. "YY", "Y" (from ESI Device Physics).

  std::vector<SyncManager> sync_managers;
  std::vector<Fmmu> fmmus;
  std::vector<Pdo> rx_pdos;          ///< Outputs (master->slave).
  std::vector<Pdo> tx_pdos;          ///< Inputs (slave->master).

  // Computed process-image placement (from SOEM IOmap pointers).
  std::uint32_t output_bits{0};
  std::uint32_t output_bit_offset{0};  ///< Bit offset of this slave's outputs in the image.
  std::uint32_t input_bits{0};
  std::uint32_t input_bit_offset{0};

  Mailbox mailbox;
  DcConfig dc;

  // Topology.
  std::uint16_t parent{0};           ///< 0 = master.
  std::uint8_t parent_port{0};
  std::uint8_t entry_port{0};

  /** Diagnostics (opt-in): byte offset, within the input process image, of this slave's 4-byte
   *  diagnostic block -- InfoData.State (bytes 0..1, filled by a cyclic AL-status read) followed by
   *  WcState (bytes 2..3, filled by the master from the datagram working counter). 0 = no
   *  diagnostic block emitted for this slave. */
  std::uint32_t diag_input_byte_offset{0};
  bool has_diag{false};

  std::vector<InitCmd> init_cmds;

  /** ETG.5001 modular slave: configured module ident list (CoE 0xF030), in slot order. Empty for
   *  monolithic slaves. eni_gen uses it to expand ESI modules into this slave's PDO set. */
  std::vector<std::uint32_t> module_idents;

  bool esi_matched{false};
  std::string esi_file;              ///< Source ESI path (diagnostics).
};

/** Aggregate logical process image (logical frame coverage). */
struct ProcessImage {
  std::uint32_t logical_base{0};     ///< Group logical start address.
  std::uint32_t outputs_byte_size{0};
  std::uint32_t inputs_byte_size{0};
  std::uint16_t expected_wkc{0};     ///< Expected working counter for the group (backend-specific).
};

/** One cyclic command within a cyclic frame (e.g. LWR for outputs, LRD for inputs). */
struct CyclicCmd {
  std::string cmd{"LWR"};            ///< "LRW","LRD","LWR","ARMW","BRD","FPRD".
  std::uint32_t log_addr{0};
  std::uint16_t data_length{0};
  std::uint16_t cnt{0};              ///< Expected working counter.
  std::uint32_t input_offset{0};     ///< Byte offset into the input image.
  std::uint32_t output_offset{0};    ///< Byte offset into the output image.
  std::string comment;
  /** Master states this command is sent in (ETG CyclicCmdType <State>). Empty = SAFEOP+OP. */
  std::vector<std::string> states;
};

struct CyclicFrame {
  std::vector<CyclicCmd> cmds;
};

/** Top-level configuration model. */
struct EniModel {
  std::string master_name{"LXMASTER"};
  std::vector<SlaveConfig> slaves;
  ProcessImage process_image;
  std::vector<CyclicFrame> cyclic_frames;
  std::uint32_t cycle_time_ns{0};
  bool dc_enabled{false};
  /** Opt-in slave-state diagnostics: per-slave InfoData.State + WcState process variables and a
   *  cyclic AL-status read frame. Not required by ETG.2100 or for I/O; off unless requested. */
  bool emit_diagnostics{false};
  /** Master-directed init commands (ENI <Master><InitCmds>): broadcast register writes sent to
   *  every slave, e.g. the DC-reset sequence that clears stale distributed-clock state at
   *  INIT->PREOP. Empty on a bus that does not run distributed clocks. */
  std::vector<InitCmd> master_init_cmds;
};

/** ESC register offsets (ETG.1000) written by the standard master-level bring-up broadcasts. */
inline constexpr std::uint16_t kEscConfiguredAddress = 0x0010;  ///< Configured station address.
inline constexpr std::uint16_t kEscDlControlAddr2    = 0x0103;  ///< DL control: 2nd address enable.
inline constexpr std::uint16_t kEscAlEventMask       = 0x0200;  ///< ECAT AL-event mask (IRQ field).
inline constexpr std::uint16_t kEscCrcErrorCounters  = 0x0300;  ///< RX error / CRC counters.
inline constexpr std::uint16_t kEscFmmuArray         = 0x0600;  ///< FMMU array (16 * 16 bytes).
inline constexpr std::uint16_t kEscSyncManagerArray  = 0x0800;  ///< SyncManager array.

/** ESC registers (ETG.1000) driven by the per-slave AL state machine. */
inline constexpr std::uint16_t kEscAlControl   = 0x0120;  ///< AL control (requested state), 288.
inline constexpr std::uint16_t kEscAlStatus    = 0x0130;  ///< AL status (actual state + code), 304.
inline constexpr std::uint16_t kEscEepromCfg   = 0x0500;  ///< EEPROM configuration (assign PDI/ECAT).
inline constexpr std::uint16_t kEscEepromCtrl  = 0x0502;  ///< EEPROM control/status + address, 1282.
inline constexpr std::uint16_t kEscEepromData  = 0x0508;  ///< EEPROM read data, 1288.

/** ETG AL-state values written to / validated against the AL control / AL status registers. */
inline constexpr std::uint8_t kAlStateInit   = 0x01;
inline constexpr std::uint8_t kAlStatePreop  = 0x02;
inline constexpr std::uint8_t kAlStateBoot   = 0x03;
inline constexpr std::uint8_t kAlStateSafeop = 0x04;
inline constexpr std::uint8_t kAlStateOp     = 0x08;

/** ESC distributed-clock register offsets (ETG.1000) used by the DC bring-up sequence. */
inline constexpr std::uint16_t kEscDcSystemTime     = 0x0910;  ///< System time (+offset/delay/diff).
inline constexpr std::uint16_t kEscDcSystemTimeDiff = 0x092C;  ///< System time difference (sync window).
inline constexpr std::uint16_t kEscDcSpeedCounter   = 0x0930;  ///< Speed-counter start.
inline constexpr std::uint16_t kEscDcTimeLoopCtrl   = 0x0934;  ///< Time-loop control (filter).
inline constexpr std::uint16_t kEscDcCyclicActivate = 0x0981;  ///< Cyclic-unit activation byte.
inline constexpr std::uint16_t kEscDcActivation     = 0x0980;  ///< AssignActivate word (0x0980/81).
inline constexpr std::uint16_t kEscDcSync0StartTime = 0x0990;  ///< SYNC0 cyclic-operation start.
inline constexpr std::uint16_t kEscDcSync0CycleTime = 0x09A0;  ///< SYNC0 cycle time.
inline constexpr std::uint16_t kEscDcSync1CycleTime = 0x09A4;  ///< SYNC1 cycle time.

/** ETG AssignActivate (ESC 0x0980) bit 8: SYNC0 enabled for this slave. */
inline constexpr std::uint16_t kDcAssignActivateSync0 = 0x0100;

/** True when the ENI actually runs SYNC0 on this slave: DC is active for it (a <DC> block was
 *  emitted/parsed, i.e. the bus needs DC) AND its AssignActivate word enables SYNC0. Keyed on
 *  `dc.active`, not merely the ESI-derived AssignActivate bit: a slave whose ESI advertises SYNC0
 *  but whose ENI was generated for an SM-event bus (no DC) must not be treated as a DC participant,
 *  otherwise DC-completeness validation flags DC commands the ENI deliberately never emitted. */
inline bool slaveNeedsSync0(const SlaveConfig& s) {
  return s.dc.has_dc && s.dc.active && (s.dc.assign_activate & kDcAssignActivateSync0) != 0;
}

}  // namespace eni
