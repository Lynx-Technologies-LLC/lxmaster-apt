#pragma once

#include "eni/eni_model.hpp"

#include <string>
#include <vector>

namespace eni {

/** Outcome of validating an ENI document against the embedded ETG.2100 schema. */
struct ValidationResult {
  bool ok{false};
  std::vector<std::string> errors;   ///< Fatal problems: the ENI must be rejected.
  std::vector<std::string> warnings; ///< Non-fatal advisories (e.g. optional DC start time absent).
};

/**
 * Validate an ENI file against the project-bundled EtherCATConfig.xsd (embedded
 * into the binary, see embedded_xsd.hpp) using libxml2. There is no schema-path
 * argument by design: the schema always ships with the binary.
 */
ValidationResult validateEniFile(const std::string& eni_path);

/** Same as validateEniFile but for an in-memory document. */
ValidationResult validateEniString(const std::string& eni_xml);

/**
 * Semantic validation of a parsed EniModel.  The XSD schema cannot enforce
 * arithmetic invariants on the cyclic commands, so this function checks them
 * explicitly.  It mirrors the bounds check that Acontis EC-Master performs
 * before starting cyclic exchange ("Cmd offset + length exceeds IN/OUT image").
 *
 * InputOffs/OutputOffs are byte positions within one combined process image, and
 * a conformant master validates BOTH on EVERY command, so for each cyclic command:
 *
 *   - input_offset  + data_length <= process_image.inputs_byte_size
 *   - output_offset + data_length <= process_image.outputs_byte_size
 *
 * It also checks distributed-clock completeness: a bus that runs SYNC0 must carry
 * the standard DC bring-up sequence -- the master-level register resets that clear
 * stale DC state at INIT->PREOP plus each SYNC0 slave's cycle-time and activation
 * writes -- because an ENI-driven master that finds them missing hangs in SAFE_OP
 * with a "DC sync" timeout. A missing (optional) SYNC0 start-time write is reported
 * as a warning rather than an error.
 *
 * Call after readEniFile() / readEniString() succeeds, before handing the model
 * to the runtime.
 */
ValidationResult validateEniModel(const EniModel& model);

}  // namespace eni
