#pragma once

#include "eni/eni_model.hpp"

#include <string>
#include <vector>

namespace eni {

/** Outcome of comparing a live bus scan to an ENI model. */
struct VerifyResult {
  bool ok{false};
  std::string error;
};

/**
 * Compare scanned slave identity to an ENI model using the same rules as the
 * runtime (EcNetwork::bringUpVerifyEni): slave count must match; for each
 * position vendor + product must match exactly; physical revision must be >=
 * the ENI-configured revision.
 */
VerifyResult verifyBusMatchesEni(const std::vector<SlaveConfig>& bus, const EniModel& eni);

}  // namespace eni
