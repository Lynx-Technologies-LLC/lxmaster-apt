#pragma once

#include <libxml/parser.h>
#include <libxml/tree.h>

#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <string>
#include <vector>

/**
 * Thin libxml2 read helpers shared by the ENI reader (eni library) and the ESI/ENI
 * parser/serializer in eni_gen. libxml2's C tree API is lower-level than a fluent
 * DOM library: element text and attributes come back as freshly allocated
 * `xmlChar*` (== unsigned char*) that the caller must free, and there is no
 * "child by name" accessor. These inline wrappers hide both the memory management
 * and the `xmlChar`/`char` cast boundary so call sites read like ordinary code.
 */
namespace eni::xml {

/** libxml2 uses xmlChar (unsigned char); reinterpret to plain char for std::string/strtoll. */
inline const char* asChar(const xmlChar* s) {
  return reinterpret_cast<const char*>(s);
}

/** xmlChar literal for libxml2 calls that take element/attribute names. */
inline const xmlChar* asXml(const char* s) {
  return reinterpret_cast<const xmlChar*>(s);
}

/** True when an element node's tag name equals `name`. */
inline bool nameIs(const xmlNode* node, const char* name) {
  return node != nullptr && node->type == XML_ELEMENT_NODE && node->name != nullptr &&
         xmlStrEqual(node->name, asXml(name)) != 0;
}

/** First child element of `parent` named `name`, or nullptr. */
inline xmlNode* firstChild(const xmlNode* parent, const char* name) {
  if (parent == nullptr) {
    return nullptr;
  }
  for (xmlNode* c = parent->children; c != nullptr; c = c->next) {
    if (nameIs(c, name)) {
      return c;
    }
  }
  return nullptr;
}

/** Invoke `fn` for every child element of `parent` named `name`, in document order. */
inline void forEachChild(const xmlNode* parent, const char* name,
                         const std::function<void(xmlNode*)>& fn) {
  if (parent == nullptr) {
    return;
  }
  for (xmlNode* c = parent->children; c != nullptr; c = c->next) {
    if (nameIs(c, name)) {
      fn(c);
    }
  }
}

/** Concatenated text content of `node` (empty when null). Frees the libxml2 buffer. */
inline std::string nodeText(const xmlNode* node) {
  if (node == nullptr) {
    return {};
  }
  xmlChar* raw = xmlNodeGetContent(node);
  if (raw == nullptr) {
    return {};
  }
  std::string out(asChar(raw));
  xmlFree(raw);
  return out;
}

/** Text of the first child element named `name` (empty when absent). */
inline std::string childText(const xmlNode* parent, const char* name) {
  return nodeText(firstChild(parent, name));
}

/** Value of attribute `name` on `node` (empty when absent). Frees the libxml2 buffer. */
inline std::string attrText(const xmlNode* node, const char* name) {
  if (node == nullptr) {
    return {};
  }
  xmlChar* raw = xmlGetProp(node, asXml(name));
  if (raw == nullptr) {
    return {};
  }
  std::string out(asChar(raw));
  xmlFree(raw);
  return out;
}

/** True when attribute `name` is present on `node`. */
inline bool hasAttr(const xmlNode* node, const char* name) {
  return node != nullptr && xmlHasProp(const_cast<xmlNode*>(node), asXml(name)) != nullptr;
}

/** Parse an ETG/ESI number: "#xABCD" or "0xABCD" (hex) or plain decimal. 0 on empty. */
inline std::int64_t parseNum(const std::string& in) {
  std::size_t b = 0, e = in.size();
  while (b < e && std::isspace(static_cast<unsigned char>(in[b]))) ++b;
  while (e > b && std::isspace(static_cast<unsigned char>(in[e - 1]))) --e;
  const std::string s = in.substr(b, e - b);
  if (s.empty()) {
    return 0;
  }
  if (s.size() > 2 && s[0] == '#' && (s[1] == 'x' || s[1] == 'X')) {
    return static_cast<std::int64_t>(std::strtoll(s.c_str() + 2, nullptr, 16));
  }
  if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
    return static_cast<std::int64_t>(std::strtoll(s.c_str() + 2, nullptr, 16));
  }
  return static_cast<std::int64_t>(std::strtoll(s.c_str(), nullptr, 10));
}

/** Number from the first child element named `name`. */
inline std::int64_t childNum(const xmlNode* parent, const char* name) {
  return parseNum(childText(parent, name));
}

/** Number from attribute `name`. */
inline std::int64_t attrNum(const xmlNode* node, const char* name) {
  return parseNum(attrText(node, name));
}

/** Decode an even-length hexBinary string ("0010ABFF") into raw bytes; skips separators. */
inline std::vector<std::uint8_t> parseHexBinary(const std::string& text) {
  std::vector<std::uint8_t> out;
  auto nibble = [](char c) -> int {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
  };
  int hi = -1;
  for (char c : text) {
    const int v = nibble(c);
    if (v < 0) {
      continue;
    }
    if (hi < 0) {
      hi = v;
    } else {
      out.push_back(static_cast<std::uint8_t>((hi << 4) | v));
      hi = -1;
    }
  }
  return out;
}

}  // namespace eni::xml
