#pragma once

#include <string_view>

namespace eni {

/**
 * The ETG.2100 EtherCATConfig.xsd, embedded into the binary at build time
 * (CMake reads EtherCATConfig.xsd and generates the backing array). The runtime
 * validator parses this in memory so schema validation works regardless of the
 * current working directory or deploy location.
 */
extern const std::string_view kEtherCATConfigXsd;

}  // namespace eni
