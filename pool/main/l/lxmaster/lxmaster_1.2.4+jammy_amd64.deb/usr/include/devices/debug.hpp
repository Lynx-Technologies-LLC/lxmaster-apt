#pragma once

#include <cstddef>
#include <cstdint>

namespace ecdev {

/**
 * Fixed-size process-data snapshot used by the cyclic executor to hand off per-cycle diagnostic
 * state to a background printer thread. Populated by the RT thread from the per-slave PDO
 * pointers and consumed later (milliseconds-scale) by a worker that formats and logs it. The
 * arrays are capped at 64 bytes — every CiA402 drive we target maps 8-12 bytes in each
 * direction, and capping avoids unbounded stack/ring usage. Larger PDO regions are truncated
 * (the struct records the original length for the printer to note).
 *
 * This is the RT record at the heart of the logging framework's hot-path invariant: the RT
 * thread only ever copies one of these into a lock-free ring (no formatting, no locks, no I/O);
 * the background logging worker turns it into text via `format(const ProcessDataSnapshot&)`.
 */
struct ProcessDataSnapshot {
  static constexpr std::size_t kMaxBytes = 64;

  int            slave_idx{0};
  int            wkc{0};
  int            expected_wkc{0};
  std::uint32_t  cycle_ns_hint{0};
  std::uint16_t  slave_state{0};
  std::uint16_t  al_statuscode{0};
  std::uint8_t   islost{0};

  std::size_t    output_bytes_total{0};  /* original Obytes (may exceed kMaxBytes) */
  std::size_t    input_bytes_total{0};   /* original Ibytes (may exceed kMaxBytes) */
  std::size_t    output_bytes_copied{0}; /* min(Obytes, kMaxBytes) */
  std::size_t    input_bytes_copied{0};  /* min(Ibytes, kMaxBytes) */

  std::uint8_t   outputs[kMaxBytes]{};
  std::uint8_t   inputs[kMaxBytes]{};
};

/**
 * Compile-time gate: `true` when the top-level CMake option `LXMASTER_ENABLE_DEBUG=ON`,
 * otherwise `false`. Every verbose (`Info`/`Debug`/`Trace`) `LX_LOG*` call site is wrapped in
 * `if constexpr (kDebugEnabled)`, so with the flag off that call tree is dead-code eliminated —
 * the strings and the report `format()` calls are dropped. `Error`/`Warn` are always compiled
 * in so production failures still surface. The heavy SAFE_OP SDO probes
 * (`ecnet::diag`) are additionally guarded by `#ifdef LXMASTER_DEBUG` in their TU.
 */
#ifdef LXMASTER_DEBUG
constexpr bool kDebugEnabled = true;
#else
constexpr bool kDebugEnabled = false;
#endif

}  // namespace ecdev
