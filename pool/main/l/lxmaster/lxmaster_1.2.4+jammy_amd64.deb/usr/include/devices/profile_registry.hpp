#pragma once

#include "devices/motion_profile.hpp"

#include "eni/eni_model.hpp"

#include <cstdint>
#include <memory>
#include <vector>

namespace ecdev {

class IDeviceProfile;

/**
 * Claim-score tiers for {@link IProfileFactory::claim}. Classification is explicit, in priority
 * order: a device class that matches a precise `vendor_id`/`product_code` identity returns
 * `kIdentityPin` and always wins; failing that, the family fallback claims by the slave's CANopen
 * `profile_no` (402/401/406) at `kProfileFamily`. Anything that claims neither is left to the
 * caller (unmatched PDO-mapping slaves are a hard error). Tiers are spaced to leave headroom for
 * future bands.
 */
namespace claim_score {
constexpr int kNone = 0;
constexpr int kProfileFamily = 500;  ///< CANopen ProfileNo family fallback (no identity match).
constexpr int kIdentityPin = 1000;   ///< Identity-matched device class (highest priority).
}  // namespace claim_score

/** Inputs a factory uses to decide on and build a profile for one ENI slave. */
struct ProfileSelectionInput {
  /** Pointer to the ENI slave descriptor for the slave being classified. Never null during a
   *  normal bring-up; the factory uses this to inspect identity (vendor/product), PDO objects,
   *  and the CANopen profile number. */
  const eni::SlaveConfig* slave{nullptr};
  /** Initial operating mode baked into the profile at construction (CSP default). Overridable at
   *  runtime via Axis::configure() between prepare() and start(). */
  DriveOpMode op_mode{DriveOpMode::Csp};
  /** Initial auto fault-reset/recover flag (off by default). Overridable via Axis::configure(). */
  bool auto_fault_reset_and_recover{false};
  /** Clear a residual fault present at OP entry (before the drive has ever enabled this run) with a
   *  bounded reset window instead of latching a stop. On by default; mid-run faults stay terminal. */
  bool startup_fault_autoreset{true};
};

/**
 * Builds the device-class profile for one slave. A new device class is supported by adding a new
 * factory (typically via {@link makeIdentityProfileFactory} + `LXMASTER_REGISTER_DEVICE`); the
 * generic device and orchestration layer never change.
 */
class IProfileFactory {
public:
  virtual ~IProfileFactory() = default;
  /** Stable diagnostic name for this factory (e.g. `"cia402:vendor-model"`). Used in log
   *  messages and error strings; must outlive the factory object (a string literal in practice).
   * @return A null-terminated string literal identifying this factory. */
  virtual const char* name() const = 0;
  /**
   * Determine whether this factory handles the given slave and how strongly it claims it.
   * The registry picks the highest-claiming factory (deterministic by registration order on ties).
   * @param slave ENI slave descriptor to inspect (identity, PDO objects, CANopen profile number).
   * @return `claim_score::kNone` (0) if this factory does not handle this slave; a positive
   *         `claim_score` value if it does — higher scores win over lower ones.
   */
  virtual int claim(const eni::SlaveConfig& slave) const = 0;
  /** Construct and return the profile for the given slave. Called only when `claim()` returned a
   *  positive score for this slave.
   * @param in Selection inputs including the ENI slave descriptor and default drive settings.
   * @return The constructed profile, or null to pin the slave as passive (no facade handle). */
  virtual std::unique_ptr<IDeviceProfile> create(const ProfileSelectionInput& in) const = 0;
};

/**
 * Registry of {@link IProfileFactory} plugins. `select()` returns the best-claiming profile for a
 * slave, or null when no factory claims it (the caller decides what an unmatched slave means).
 *
 * The process-wide {@link builtin} registry is populated entirely by self-registering device-class
 * translation units (`LXMASTER_REGISTER_DEVICE`); there is no central list of built-in factories.
 */
class ProfileRegistry {
public:
  /** Add a factory to this registry. Factories are consulted in registration order; the highest
   *  `claim()` score wins. Called at static-init time by `LXMASTER_REGISTER_DEVICE`.
   * @param factory The factory to register; ownership is transferred to the registry. */
  void registerFactory(std::unique_ptr<IProfileFactory> factory);
  /** Select and construct the best-matching profile for a slave. Iterates all registered
   *  factories, picks the one with the highest `claim()` score, and calls its `create()`.
   * @param in Selection inputs including the ENI slave descriptor and default drive settings.
   * @return The constructed profile, or null when no factory claims the slave. */
  std::unique_ptr<IDeviceProfile> select(const ProfileSelectionInput& in) const;
  /**
   * Like `select(in)`, but also considers app-supplied factories ahead of the built-ins. Ties
   * favour `extra_factories`, so an application can override a built-in for one run without
   * static registration (e.g. via `NetworkConfig::extra_profile_factories`).
   * @param in Selection inputs including the ENI slave descriptor and default drive settings.
   * @param extra_factories App-supplied factories considered before the registered built-ins.
   * @return The constructed profile, or null when no factory claims the slave. */
  std::unique_ptr<IDeviceProfile> select(
      const ProfileSelectionInput& in,
      const std::vector<std::shared_ptr<IProfileFactory>>& extra_factories) const;

  /** The process-wide registry, populated by self-registering device-class TUs at static init.
   * @return Reference to the singleton built-in registry. */
  static ProfileRegistry& builtin();

private:
  std::vector<std::unique_ptr<IProfileFactory>> factories_;
};

}  // namespace ecdev
