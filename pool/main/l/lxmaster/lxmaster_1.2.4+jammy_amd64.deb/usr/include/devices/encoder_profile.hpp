#pragma once

#include <cstdint>

namespace ecdev {

/**
 * Facade-facing contract for an encoder / position sensor (CiA 406 family). The `Encoder` facade
 * depends only on this. Safe to call from an application thread while the RT cycle runs.
 */
class IEncoderProfile {
public:
  virtual ~IEncoderProfile() = default;

  /** Latest position value (counts) from the sensor. */
  virtual std::int32_t position() const noexcept = 0;
  /** Latest velocity value, if the sensor maps one (otherwise 0). */
  virtual std::int32_t velocity() const noexcept = 0;
  /** Raw status/operating-status word, if mapped (otherwise 0). */
  virtual std::uint16_t status() const noexcept = 0;
};

}  // namespace ecdev
