#pragma once

#include "devices/profile_registry.hpp"

#include "eni/eni_model.hpp"

#include <cstdint>
#include <functional>
#include <memory>

namespace ecdev {

class IDeviceProfile;

/**
 * Exact device identity a device class serves. Matching is explicit: a slave matches only when its
 * `vendor_id` and `product_code` are equal and (when bounded) its `revision` falls in the inclusive
 * `[revision_min, revision_max]` window. A bound of 0 means "unbounded on that side", so the common
 * `{vendor, product}` form matches every revision.
 */
struct DeviceIdentityMatch {
  std::uint32_t vendor_id{0};
  std::uint32_t product_code{0};
  std::uint32_t revision_min{0};  ///< 0 = no lower bound.
  std::uint32_t revision_max{0};  ///< 0 = no upper bound (any revision).

  bool matches(const eni::SlaveConfig& slave) const;
};

/** Builds the device-class profile for a matched slave. Returning null pins the slave as passive. */
using ProfileCreateFn = std::function<std::unique_ptr<IDeviceProfile>(const ProfileSelectionInput&)>;

/**
 * Make an {@link IProfileFactory} that claims a slave (at `claim_score::kIdentityPin`) exactly when
 * `match` matches its identity, and builds the profile via `fn`. `name` is a stable diagnostic
 * label and must outlive the factory (a string literal in practice).
 *
 * This is the low-boilerplate way to author a device class: bind an identity to any profile
 * (an existing behaviour like `CiA402DriveProfile`, or a brand-new `IDeviceProfile`/facade subclass)
 * and register it with `LXMASTER_REGISTER_DEVICE`.
 */
std::unique_ptr<IProfileFactory> makeIdentityProfileFactory(DeviceIdentityMatch match,
                                                            ProfileCreateFn fn, const char* name);

}  // namespace ecdev
