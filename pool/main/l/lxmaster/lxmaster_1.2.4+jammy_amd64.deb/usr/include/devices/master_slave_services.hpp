#pragma once

#include "devices/slave_services.hpp"

#include <cstdint>

namespace ecmaster {
struct SlaveContext;
}

namespace ecdev {

/**
 * Backend-neutral {@link ISlaveServices}. Constructed by the orchestration layer around an
 * `ecmaster::SlaveContext` and handed to a device/profile during configuration callbacks. This is
 * the single adapter that translates the backend-free service contract into
 * `ecmaster::EcMaster` SDO / register / process-data calls. Profiles depend only on
 * `ISlaveServices`; only this class knows about the master, and it works against either backend
 * (LXEC or SOEM) since it speaks only the neutral `EcMaster` API.
 */
class MasterSlaveServices final : public ISlaveServices {
public:
  explicit MasterSlaveServices(ecmaster::SlaveContext& ctx) : ctx_(&ctx) {}

  std::uint16_t slaveIndex() const override;
  int writeSdo(std::uint16_t index, std::uint8_t sub, bool complete_access, const void* data,
               int size) override;
  int readSdo(std::uint16_t index, std::uint8_t sub, bool complete_access, void* data,
              int* size) override;
  int readRegister(std::uint16_t ado, void* data, std::uint16_t len) override;
  void exchangeProcessData() override;
  void drainErrors() override;

private:
  ecmaster::SlaveContext* ctx_;
};

}  // namespace ecdev
