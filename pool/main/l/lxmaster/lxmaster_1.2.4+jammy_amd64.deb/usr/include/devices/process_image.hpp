#pragma once

#include "eni/eni_model.hpp"

#include <cstddef>
#include <cstdint>
#include <vector>

namespace ecdev {

/**
 * Resolved location of one mapped CoE object inside a slave's process image. Produced once at
 * setup time by {@link ProcessImage::resolve}; the profile then reads/writes via this handle on
 * the RT cyclic path with no map lookup. `valid == false` means the object is not mapped into the
 * slave's PDOs (the profile must handle that gracefully).
 */
struct PdoEntryRef {
  bool valid{false};
  bool is_output{false};      ///< true: lives in the output (RxPdo) image; false: input (TxPdo).
  std::uint32_t byte_offset{0};  ///< Byte offset within the slave's output/input region.
  std::uint8_t bit_offset{0};    ///< Sub-byte bit offset (0..7) for packed booleans.
  std::uint8_t bit_len{0};       ///< Object width in bits.
};

/**
 * Per-slave process-image accessor: the narrow cyclic-path contract that device profiles use.
 *
 * It owns the offset tables derived from an ENI `<Slave>`'s RxPdo/TxPdo entry lists (CoE object
 * index:sub and human name -> byte/bit offset) and binds, each cycle, to the live PDO byte
 * buffers the backend exposes for that slave. Profiles `resolve()` the objects they care about once,
 * then use the typed read/write helpers in `writeOutputs`/`readInputs`.
 *
 * Deliberately holds NO backend types and no EtherCAT master reference: the only thing a profile can
 * do through a ProcessImage is shuffle bytes in the bound PDO window. That makes the RT path
 * auditable -- a profile physically cannot issue a blocking SDO from a cyclic hook.
 */
class ProcessImage {
public:
  ProcessImage() = default;

  /** Build the offset tables from an ENI slave (walks rx_pdos then tx_pdos in order). */
  static ProcessImage fromSlaveConfig(const eni::SlaveConfig& slave);

  /** Bind the live PDO byte buffers for the current cycle. Cheap; call once per cycle. */
  void bind(std::uint8_t* outputs, std::size_t output_bytes, const std::uint8_t* inputs,
            std::size_t input_bytes) noexcept;

  /** Resolve a CoE object (index:sub) to a stable handle. Do this once at setup. */
  PdoEntryRef resolve(std::uint16_t index, std::uint8_t sub) const noexcept;

  /* Typed accessors via a resolved ref. Return false when the ref is invalid or the bound
   * buffer is too small. Multi-byte values are little-endian (host order on supported targets). */
  bool readU8(const PdoEntryRef& ref, std::uint8_t* out) const noexcept;
  bool readU16(const PdoEntryRef& ref, std::uint16_t* out) const noexcept;
  bool readU32(const PdoEntryRef& ref, std::uint32_t* out) const noexcept;
  bool readI8(const PdoEntryRef& ref, std::int8_t* out) const noexcept;
  bool readI16(const PdoEntryRef& ref, std::int16_t* out) const noexcept;
  bool readI32(const PdoEntryRef& ref, std::int32_t* out) const noexcept;
  bool readBit(const PdoEntryRef& ref, bool* out) const noexcept;

  bool writeU8(const PdoEntryRef& ref, std::uint8_t value) noexcept;
  bool writeU16(const PdoEntryRef& ref, std::uint16_t value) noexcept;
  bool writeU32(const PdoEntryRef& ref, std::uint32_t value) noexcept;
  bool writeI8(const PdoEntryRef& ref, std::int8_t value) noexcept;
  bool writeI16(const PdoEntryRef& ref, std::int16_t value) noexcept;
  bool writeI32(const PdoEntryRef& ref, std::int32_t value) noexcept;
  bool writeBit(const PdoEntryRef& ref, bool value) noexcept;

  /** All resolved entries, in image order (diagnostics / enumeration by facades). */
  struct Entry {
    std::uint16_t index{0};
    std::uint8_t sub_index{0};
    std::uint8_t bit_len{0};
    bool is_output{false};
    std::uint32_t byte_offset{0};
    std::uint8_t bit_offset{0};
  };
  const std::vector<Entry>& entries() const noexcept { return entries_; }

private:
  const std::uint8_t* readBase(const PdoEntryRef& ref, std::size_t need) const noexcept;
  std::uint8_t* writeBase(const PdoEntryRef& ref, std::size_t need) noexcept;

  std::vector<Entry> entries_;

  std::uint8_t* outputs_{nullptr};
  std::size_t output_bytes_{0};
  const std::uint8_t* inputs_{nullptr};
  std::size_t input_bytes_{0};
};

}  // namespace ecdev
