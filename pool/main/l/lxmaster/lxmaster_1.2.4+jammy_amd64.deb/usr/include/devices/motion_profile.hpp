#pragma once

#include <cstdint>

namespace ecdev {

/**
 * Cyclic operating mode for a CiA 402 (CANopen-over-EtherCAT) servo drive. Maps 1:1 to the
 * DS402 modes-of-operation object (0x6060):
 *
 *   - **Csp** (8): Cyclic Synchronous Position — commands target position 0x607A (INT32).
 *   - **Csv** (9): Cyclic Synchronous Velocity — commands target velocity 0x60FF (INT32).
 *   - **Cst** (10): Cyclic Synchronous Torque  — commands target torque 0x6071 (INT16, per-mille).
 *
 * Each mode's cyclic facts (target object, data width, neutral-target value) live in the
 * `OpModeTraits` table in `cia402_drive_profile.cpp`; no mode is special-cased.
 */
enum class DriveOpMode {
  Csp,
  Csv,
  Cst,
};

/**
 * Facade-facing contract for a motion (drive) device. This is the ONLY surface the `Axis` facade
 * depends on -- it knows nothing about CiA402 controlwords, the backend, or the ENI. Any drive profile
 * (CiA402 today, others later) implements it so the same `Axis` works across drive families.
 *
 * All methods are safe to call from an application thread concurrently with the RT cycle: the
 * implementation backs them with lock-free state.
 *
 * Pre-start configuration (call between prepare() and start()):
 *   setOperatingMode() / setAutoFaultRecover() are not thread-safe with the RT cycle; call them
 *   only after prepare() and before start(). Default no-ops make non-CiA402 profiles unaffected.
 */
class IMotionProfile {
public:
  virtual ~IMotionProfile() = default;

  /* ---- Mode + fault configuration. ---- */
  /** Select the cyclic operating mode (CSP / CSV / CST). Call before start() to choose the initial
   *  mode, or while running to switch live. A live switch takes effect only when the ENI maps
   *  modes-of-operation (0x6060) into the RxPDO (eni_gen does this for CiA402 drives); otherwise the
   *  drive runs the mode set via SDO at PRE_OP and a later call has no cyclic effect. RT-safe.
   *  Default no-op so non-CiA402 profiles are unaffected.
   * @param mode The desired cyclic operating mode. */
  virtual void setOperatingMode(DriveOpMode mode) noexcept {}
  /** Set the CiA402 auto fault-reset/recover behaviour. Call between prepare() and start(); not
   *  RT-safe.
   * @param enable `true` to automatically reset and re-enable after a mid-run fault; `false`
   *               (default) to treat faults as terminal stops. */
  virtual void setAutoFaultRecover(bool enable) noexcept {}

  /* ---- Commands (application thread). ---- */
  /** Command a CSP target position. Implicitly leaves "hold actual" mode.
   * @param counts Target position in encoder counts (CiA402 0x607A). */
  virtual void setTargetPosition(std::int32_t counts) noexcept = 0;
  /** Command a CSV target velocity. Only honoured by a profile running in CSV mode.
   * @param counts_per_sec Target velocity in encoder counts per second (CiA402 0x60FF). */
  virtual void setTargetVelocity(std::int32_t counts_per_sec) noexcept = 0;
  /** Command a CST target torque. Only honoured by a profile running in CST mode.
   * @param per_mille_rated Target torque in per-mille of rated torque (CiA402 0x6071). */
  virtual void setTargetTorque(std::int32_t per_mille_rated) noexcept = 0;
  /** Request the drive walk to Operation Enabled (cancels a prior disable request). */
  virtual void requestEnable() noexcept = 0;
  /** Request the drive walk back to a de-energised resting state. */
  virtual void requestDisable() noexcept = 0;
  /** One-shot fault-reset edge (acted on only while the drive reports Fault). */
  virtual void requestFaultReset() noexcept = 0;

  /* ---- Status (application thread). ---- */
  /** Actual position reported by the drive (encoder counts, CiA402 0x6064). RT-safe. */
  virtual std::int32_t actualPosition() const noexcept = 0;
  /** Last target position commanded to the drive (encoder counts). RT-safe. */
  virtual std::int32_t targetPosition() const noexcept = 0;
  /** Actual velocity reported by the drive (encoder counts/s, CiA402 0x606C). Returns 0 if
   *  the drive does not map this object. RT-safe. */
  virtual std::int32_t actualVelocity() const noexcept = 0;
  /** Raw DS402 statusword (CiA402 0x6041). RT-safe. */
  virtual std::uint16_t statusword() const noexcept = 0;
  /** True when the DS402 state machine is in the Operation Enabled state. RT-safe. */
  virtual bool isOperationEnabled() const noexcept = 0;
  /** True when the drive reports a latched fault (DS402 Fault state, statusword bit 3). RT-safe. */
  virtual bool isFault() const noexcept = 0;
  /** Drive's reported actual torque (CiA402 0x6077, per-mille of rated). 0 if the profile does
   * not map it. Diagnostic only. */
  virtual std::int32_t actualTorque() const noexcept { return 0; }
  /** Drive's modes-of-operation display (CiA402 0x6061; 8=CSP, 9=CSV, 10=CST). 0 if unmapped. */
  virtual std::int32_t modeDisplay() const noexcept { return 0; }
};

}  // namespace ecdev
