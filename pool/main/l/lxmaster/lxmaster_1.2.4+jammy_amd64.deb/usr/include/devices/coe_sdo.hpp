#pragma once

#include <cstdint>

namespace ecmaster {
class EcMaster;
}

/**
 * Single source of truth for the small CoE (CANopen over EtherCAT) SDO helpers that the
 * device layer needs during PreOP / SAFE_OP configuration. They route every transfer through
 * the backend-neutral `ecmaster::EcMaster` (SDO read/write + abort capture + error draining), so
 * the device layer no longer depends on any EtherCAT backend header.
 *
 * The read helpers diverge only in *one* dimension — what they do with the CoE error queue after
 * the transfer — so that single decision is made explicit via `SdoDrain` rather than forking the
 * implementation per call site. `CiA402Device` drains unconditionally; the `debug` and
 * diagnostic-example call sites leave the queue intact so the abort code can be recovered.
 */
namespace ecdev::coe {

/** Post-transfer policy for the CoE error queue. */
enum class SdoDrain {
  kNever,   ///< Leave the queue untouched (caller inspects/pops it).
  kAlways,  ///< Drain every queued error after the transfer (success or failure).
};

/** Read a UINT16 SDO. Returns false on transfer failure or short read. */
bool tryReadSdoU16(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                   std::uint8_t sub, std::uint16_t* out, SdoDrain drain = SdoDrain::kNever);

/** Read a UINT32 SDO (single-access only). Returns false on transfer failure or short read. */
bool tryReadSdoU32(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                   std::uint8_t sub, std::uint32_t* out, SdoDrain drain = SdoDrain::kNever);

}  // namespace ecdev::coe
