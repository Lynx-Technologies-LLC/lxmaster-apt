#pragma once

#include "devices/device_profile.hpp"
#include "devices/io_profile.hpp"
#include "devices/process_image.hpp"

#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <vector>

namespace ecdev {

struct ProfileSelectionInput;

/** Build a GenericIoProfile. Bind it to a device identity with `makeIdentityProfileFactory`. */
std::unique_ptr<IDeviceProfile> makeGenericIoProfile(const ProfileSelectionInput& in);

/**
 * Protocol-agnostic digital/analog I/O profile. Exposes a slave's mapped process data as typed
 * channels through {@link IIoProfile}, which the `IoModule` facade wraps -- with no dependence on
 * CoE, a specific CiA profile, or any vendor object layout. Works for simple (non-CoE) terminals
 * (e.g. Beckhoff EL2xxx/EL1xxx) as well as CoE I/O.
 *
 * Channel model (purely structural, from the process image):
 *   - A PDO object in the CiA 401 digital area (0x6000-0x63FF) is treated as packed booleans and
 *     expanded to one digital channel per bit.
 *   - Any other 1-bit entry is a single digital channel (e.g. Beckhoff 0x7000:01 BOOL outputs).
 *   - Any wider entry is a scalar analog channel (8/16/32-bit).
 * Direction follows the PDO (RxPDO = output, TxPDO = input).
 *
 * Subclasses (e.g. {@link CiA401IoProfile}) may override `profileName()` and add device-class
 * specific setup; the channel logic here is shared.
 */
class GenericIoProfile : public IDeviceProfile, public IIoProfile {
public:
  static constexpr std::size_t kMaxDigital = 256;
  static constexpr std::size_t kMaxAnalog = 64;

  const char* profileName() const override { return "generic-io"; }
  IIoProfile* asIo() noexcept override { return this; }

  void resolveTopology(const ProcessImage& image) override { resolve(image); }
  std::string configurePreOp(ISlaveServices& svc, ProcessImage& image) override;
  void writeOutputs(ProcessImage& image, std::uint64_t cycle_count) override;
  void readInputs(const ProcessImage& image, bool wkc_valid, bool operational) override;

  /* ---- IIoProfile ---- */
  std::size_t digitalInputCount() const noexcept override { return di_.size(); }
  std::size_t digitalOutputCount() const noexcept override { return do_.size(); }
  std::size_t analogInputCount() const noexcept override { return ai_.size(); }
  std::size_t analogOutputCount() const noexcept override { return ao_.size(); }

  bool digitalInput(std::size_t ch) const noexcept override {
    return ch < di_.size() && di_state_[ch].load(std::memory_order_acquire);
  }
  bool digitalOutput(std::size_t ch) const noexcept override {
    return ch < do_.size() && do_state_[ch].load(std::memory_order_acquire);
  }
  void setDigitalOutput(std::size_t ch, bool value) noexcept override {
    if (ch < do_.size()) do_state_[ch].store(value, std::memory_order_release);
  }
  std::int32_t analogInput(std::size_t ch) const noexcept override {
    return ch < ai_.size() ? ai_state_[ch].load(std::memory_order_acquire) : 0;
  }
  std::int32_t analogOutput(std::size_t ch) const noexcept override {
    return ch < ao_.size() ? ao_state_[ch].load(std::memory_order_acquire) : 0;
  }
  void setAnalogOutput(std::size_t ch, std::int32_t value) noexcept override {
    if (ch < ao_.size()) ao_state_[ch].store(value, std::memory_order_release);
  }

private:
  void resolve(const ProcessImage& image);

  std::vector<PdoEntryRef> di_, do_, ai_, ao_;
  std::array<std::atomic<bool>, kMaxDigital> di_state_{};
  std::array<std::atomic<bool>, kMaxDigital> do_state_{};
  std::array<std::atomic<std::int32_t>, kMaxAnalog> ai_state_{};
  std::array<std::atomic<std::int32_t>, kMaxAnalog> ao_state_{};
  bool resolved_{false};
};

}  // namespace ecdev
