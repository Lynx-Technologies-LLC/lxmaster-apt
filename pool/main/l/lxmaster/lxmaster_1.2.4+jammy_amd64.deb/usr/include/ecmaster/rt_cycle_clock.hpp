#pragma once

#include <cstdint>

namespace ecmaster {

/** Monotonic deadline sleep for cyclic masters. */
class RtCycleClock {
public:
  /** Current time in nanoseconds (CLOCK_MONOTONIC). */
  static std::uint64_t nowNs();
  /** Sleep until `deadline_ns` (no sleep if already late). */
  static void sleepUntil(std::uint64_t deadline_ns);
};

}  // namespace ecmaster
