#pragma once

#include <cstddef>
#include <cstdint>
#include <ctime>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace ecmaster {

/** Default IOmap buffer size handed to `configMap()` — one MTU-ish page covers typical drives. */
inline constexpr std::size_t kDefaultIoMapBytes = 4096;

/* --------------------------------------------------------------------------------------------
 * Neutral EtherCAT vocabulary. These replace the SOEM `EC_STATE_*` / `EC_TIMEOUT*` constants and
 * the leaked `ec_slavet` so that no consumer of ecmaster includes a backend header. The numeric
 * values intentionally match both SOEM's `EC_STATE_*` and LXEC's `lxec::State`, so each backend
 * maps `EcState` to its own enum by a plain cast.
 * ------------------------------------------------------------------------------------------ */

/** EtherCAT State Machine (ESM) state. Values match the on-wire AL state nibble. */
enum class EcState : std::uint8_t {
  None = 0x00,
  Init = 0x01,
  PreOp = 0x02,
  Boot = 0x03,
  SafeOp = 0x04,
  Op = 0x08,
  Ack = 0x10,  ///< Error-acknowledge bit (OR'd onto a base state).
};

/** Backend-neutral timeouts in microseconds (mirror SOEM's EC_TIMEOUT* / LXEC's cfg::kTimeout*). */
inline constexpr int kTimeoutRet = 2000;          ///< Frame return timeout.
inline constexpr int kTimeoutSafe = 20000;        ///< Safe mailbox transfer timeout.
inline constexpr int kTimeoutRxMailbox = 700000;  ///< Mailbox receive timeout.
inline constexpr int kTimeoutState = 2000000;     ///< ESM state-change poll timeout.

/**
 * Runtime-tunable protocol timeouts (microseconds) and retry counts, mirroring LXEC's
 * `lxec::Timeouts`. The defaults match the built-in backend baselines. A consumer fills this in
 * (e.g. from host configuration) and hands it to `EcMaster::setTimeouts()` before `init()`. The
 * LXEC backend applies them on its wire paths; the SOEM backend ignores them because its timeouts
 * are compile-time `#define`s.
 */
struct Timeouts {
  int frame_return{kTimeoutRet};       ///< tx frame to return to rx.
  int frame_return3{kTimeoutRet * 3};  ///< safe transfer, triple retry.
  int safe{kTimeoutSafe};              ///< "safe" variant (e.g. wireless).
  int eeprom{20000};                   ///< EEPROM access.
  int tx_mailbox{20000};               ///< mailbox transmit cycle.
  int rx_mailbox{kTimeoutRxMailbox};   ///< mailbox receive cycle.
  int state{kTimeoutState};            ///< state-change poll.
  int retries{3};                      ///< retries when WKC <= 0.
};

/** ESC register: distributed-clock system time difference (sign-magnitude, 0x092C). */
inline constexpr std::uint16_t kRegDcSysDiff = 0x092C;

/** ESC register: DL status (link / loop / communication per port, 0x0110). ETG.1000 standard. */
inline constexpr std::uint16_t kRegDlStatus = 0x0110;

/** Result of a single broadcast ESM transition (`requestBusState`). */
struct StateTransitionResult {
  bool success{false};
  EcState target_state{EcState::None};
  std::string detail;
};

/** Result of `EcMaster::shutdownBus()` — best-effort walk-down with per-step confirmation. */
struct BusShutdownResult {
  bool sync0_disabled{true};
  bool pre_op_reached{false};
  bool init_reached{false};
  std::string detail;
};

/** One sync-manager descriptor (for ENI generation). */
struct SyncManagerInfo {
  std::uint16_t start_address{0};
  std::uint16_t length{0};
  std::uint32_t flags{0};
  std::uint8_t type{0};  ///< 1=MbxOut, 2=MbxIn, 3=Outputs, 4=Inputs (ETG numbering).
};

/** One FMMU descriptor (for ENI generation). */
struct FmmuInfo {
  std::uint32_t log_start{0};
  std::uint16_t log_length{0};
  std::uint8_t log_start_bit{0};
  std::uint8_t log_end_bit{0};
  std::uint16_t phys_start{0};
  std::uint8_t phys_start_bit{0};
  std::uint8_t type{0};
  std::uint8_t active{0};
};

/** Mailbox geometry + advertised protocol flags (for ENI generation). */
struct MailboxInfo {
  std::uint16_t out_start{0};
  std::uint16_t out_size{0};
  std::uint16_t in_start{0};
  std::uint16_t in_size{0};
  std::uint16_t proto{0};  ///< Bit flags: CoE/FoE/EoE/SoE/... (ETG numbering).
};

/** Maximum sync managers / FMMUs surfaced per slave (matches both backends' caps). */
inline constexpr int kMaxSyncManagers = 8;
inline constexpr int kMaxFmmu = 4;

/**
 * Backend-neutral snapshot of one slave's discovered state. Returned by value from
 * `EcMaster::slaveInfo()`; `valid` is false for an out-of-range index. Hot-path code that only
 * needs the process-image pointers should use the lighter `pdoImage()` instead.
 */
struct SlaveInfo {
  bool valid{false};

  // Identity / ESM
  std::uint16_t state{0};            ///< Raw AL state byte (mask 0x0F for the ESM state).
  std::uint16_t al_status_code{0};
  bool has_dc{false};
  std::uint8_t is_lost{0};
  std::uint16_t config_addr{0};
  std::uint16_t alias{0};
  std::uint32_t vendor_id{0};
  std::uint32_t product_id{0};
  std::uint32_t revision{0};
  char name[64]{};

  // Process image
  std::uint8_t* outputs{nullptr};
  std::uint8_t* inputs{nullptr};
  std::uint32_t output_bytes{0};
  std::uint32_t input_bytes{0};
  std::uint32_t output_bits{0};
  std::uint32_t input_bits{0};
  std::uint32_t output_offset{0};  ///< Byte offset of outputs within the group process image.
  std::uint32_t input_offset{0};   ///< Byte offset of inputs within the group process image.
  std::uint8_t output_startbit{0};
  std::uint8_t input_startbit{0};

  // Topology
  std::uint16_t parent{0};
  std::uint8_t parent_port{0};
  std::uint8_t entry_port{0};

  // Mailbox / sync managers / FMMUs (ENI generation)
  MailboxInfo mailbox;
  SyncManagerInfo sm[kMaxSyncManagers]{};
  FmmuInfo fmmu[kMaxFmmu]{};
};

/** Lightweight, hot-path process-image view of one slave (live pointers into the IOmap). */
struct PdoImage {
  std::uint8_t* outputs{nullptr};
  std::size_t output_bytes{0};
  std::uint8_t* inputs{nullptr};
  std::size_t input_bytes{0};
};

/** Group-level process-image geometry (for ENI generation). */
struct ProcessImageInfo {
  std::uint32_t logical_base{0};
  std::size_t output_bytes{0};
  std::size_t input_bytes{0};
};

/* --------------------------------------------------------------------------------------------
 * ENI-driven process-data map (see EcMaster::configMapFromEni).
 * The runtime fills these tables from the loaded ENI so SyncManagers and FMMUs are programmed from
 * the ENI rather than re-derived from the live bus. Backend-neutral: ecnet fills them from
 * eni::EniModel without ecmaster depending on libs/eni.
 * ------------------------------------------------------------------------------------------ */

/** One process-data sync manager to program, from the ENI <Sm> / SM register image. The SM control
 *  byte is not carried: it is fixed by the transfer direction (`type`), which the backend applies. */
struct SyncManagerConfig {
  std::uint8_t index{0};          ///< SM slot 0..15.
  std::uint16_t start_address{0};
  std::uint16_t length{0};
  std::uint8_t type{0};           ///< 1 MbxWr, 2 MbxRd, 3 Out, 4 In (ETG numbering).
  bool enable{true};
};

/** One FMMU to program, from the ENI FMMU register image (type is the ESC code: 1 in, 2 out). */
struct FmmuConfig {
  std::uint32_t log_start{0};
  std::uint16_t log_length{0};
  std::uint8_t log_start_bit{0};
  std::uint8_t log_end_bit{0};
  std::uint16_t phys_start{0};
  std::uint8_t phys_start_bit{0};
  std::uint8_t type{0};           ///< ESC FMMU type: 1 = inputs (read), 2 = outputs (write).
  bool active{false};
};

/** Per-slave process-data map derived from the ENI, keyed by 1-based bus position. */
struct SlaveProcessMap {
  std::uint16_t position{0};
  std::vector<SyncManagerConfig> sms;   ///< Process-data SMs (mailbox SMs may be omitted).
  std::vector<FmmuConfig> fmmus;
  std::uint32_t output_bits{0};         ///< Total mapped output bits for this slave.
  std::uint32_t input_bits{0};          ///< Total mapped input bits for this slave.
};

/**
 * Canonical one-slave diagnostic suffix: `" [slave <i> state=0x.. AL=0x.. (<almsg>)]"`.
 * The single source of truth for the slave-status formatting that bring-up, the cyclic
 * executor, and error paths all emit. `extra_note`, when non-null, is appended inside the
 * bracket — used for the "masked ESM" annotation. The AL-code text comes from the active
 * backend's diagnostics table.
 */
std::string formatSlaveAlStatus(int index, const SlaveInfo& slave,
                                const char* extra_note = nullptr);

/**
 * Human-readable text for an AL status code, from the active backend's diagnostics table
 * (SOEM `ec_ALstatuscode2string`, LXEC `lxec::diag::al_status_text`). Never null; returns an
 * empty string for an unknown code.
 */
const char* alStatusText(std::uint16_t al_status_code) noexcept;

/**
 * Backend-neutral EtherCAT master facade. Exactly one backend implementation
 * (`ec_master_soem.cpp` or `ec_master_lxec.cpp`) is compiled and linked; this header exposes no
 * backend type. The active backend is selected at configure time (LXEC by default,
 * `-DLXMASTER_USE_SOEM=ON` for SOEM).
 */
class EcMaster {
public:
  EcMaster();
  ~EcMaster();

  EcMaster(const EcMaster&) = delete;
  EcMaster& operator=(const EcMaster&) = delete;

  /**
   * Override the runtime protocol timeouts / retry counts before `init()`. Honored by the LXEC
   * backend (copied onto its `lxec::Master::timeouts`); a silent no-op on SOEM, whose timeouts are
   * compile-time. Has no effect once the bus is open.
   */
  void setTimeouts(const Timeouts& timeouts);

  /** Open raw socket on interface (e.g. `eth0`). */
  bool init(const char* ifname);

  // Human-readable failure reason when init() returned false due to a license-gate denial.
  // Empty on success or when the backend surfaced its own error (e.g. NIC open failed).
  const std::string& initError() const;

  /** Discover slaves and reach PRE_OP. */
  bool configInit(bool useTable);

  /**
   * Distributed clocks and Sync0.
   * Call **after** `config_map` — same order as the canonical map → DC sequence.
   */
  bool configDc();

  /**
   * Activate (or disable) SYNC0 on a single DC-capable slave with that slave's own SYNC0 period
   * and shift. This is the ENI-authoritative entry point: the orchestrator passes each slave's
   * `<DC><CycleTime0>` / `<DC><ShiftTime>` so the master programs exactly what the ENI describes,
   * rather than one uniform period/shift for the whole bus. No-op (returns true) for a slave
   * without DC. Must run while the slave is at PRE_OP/SAFE_OP, never from the RT cyclic path.
   *
   * `assign_activate` is the slave's ENI AssignActivate word (ESC 0x0980); its high byte is the
   * DCSYNCACT activation register, so 0x0300 = cyclic+SYNC0 and 0x0700 = cyclic+SYNC0+SYNC1. This
   * makes the ENI authoritative over which sync signals run. LXEC honors it; SOEM ignores it (its
   * ecx_dcsync0 always programs SYNC0-only). Ignored when `enable` is false.
   */
  bool dcSync0(std::uint16_t slave_index, bool enable, std::uint32_t cycle_ns,
               std::int32_t cycle_shift_ns, std::uint16_t assign_activate);

  /**
   * Register a per-slave PRE_OP → SAFE_OP mailbox configuration hook before mapping. The hook is
   * invoked during `configMap()` for each slave that has one, while the slave is in PRE_OP and
   * before its sync managers are sized (so it may remap PDO / write CoE). A non-zero return aborts
   * the map.
   */
  using Po2SoHook = std::function<int(std::uint16_t slave_index)>;
  void setPo2SoHook(std::uint16_t slave_index, Po2SoHook hook);

  /** Map process data. IOmap buffer is owned by EcMaster. */
  bool configMap(std::size_t io_buffer_bytes);

  /**
   * ENI-authoritative variant of `configMap()`: program each slave's process-data SyncManagers and
   * FMMUs from the supplied per-slave tables (built from the loaded ENI) instead of deriving them
   * from the live CoE/SII bus. The live SII sync-manager records are still read to confirm each
   * programmed SM's physical start address matches the ENI; a mismatch (or unreadable SII) fails
   * the map. Per-slave PRE_OP config hooks (CoE PDO assignment) still run first. The IOmap buffer is
   * owned by EcMaster. Honored by LXEC; the SOEM backend falls back to `configMap()` because its
   * mapping cannot be driven from an explicit table.
   */
  bool configMapFromEni(const std::vector<SlaveProcessMap>& slave_maps, std::size_t io_buffer_bytes);

  /**
   * Blocking broadcast to `target_state` at `kTimeoutState`, PDO-free — the entry point for the
   * INIT/PRE_OP legs of bring-up. Returns true once every slave confirms the masked state.
   *
   * `requestState(EcState::Init)` is intended right after `configInit()` so that drives left in a
   * stale state from a previous unclean shutdown are forcibly reset to INIT before the normal
   * INIT → PRE_OP → SAFE_OP → OP walk begins. `requestState(EcState::PreOp)` follows that reset
   * before `configMap()`, since CoE/PDO SDOs require PRE_OP.
   */
  bool requestState(EcState target_state);

  /**
   * Like `requestState`, but returns the full `StateTransitionResult` instead of just the success
   * bool — so bring-up can surface the timeout prefix ("timeout waiting for ESM 0x..") and the
   * early-exit reasons ("master not open", "no slaves enumerated") that `requestState` discards.
   */
  StateTransitionResult requestStateWithDetail(EcState target_state);

  /**
   * Re-run mapping from PRE_OP (hooks then SM programming). Use when the first map hit a cold CoE
   * mailbox (PDO remap wkc=0) after several successful sessions.
   */
  bool refreshProcessDataMapping(int timeout_us_per_step = kTimeoutState * 4);

  /**
   * True when every enumerated slave's masked ESM state equals `expected_state`, the ESM error
   * bit is clear, and the AL status code is zero. Call `refreshStates()` first if the cache may be
   * stale.
   */
  bool allSlavesInState(EcState expected_state) const;

  /** Slaves whose masked ESM state differs from `expected_state` (for diagnostics). */
  std::string unexpectedSlaveStates(EcState expected_state) const;

  /** Broadcast `target_state` via AL control — does not wait for confirmation. */
  void writeBusStateRequest(EcState target_state);

  /**
   * Per-slave AL-control state request, the per-slave analogue of `writeBusStateRequest`. Used by
   * per-device bring-up to walk only the slaves whose configured max bring-up state allows it,
   * leaving the others where they are. Out-of-range indices are ignored. Does not wait.
   */
  void writeSlaveState(std::uint16_t index, EcState state);

  /** Issue `writeSlaveState(i, state)` for every index in `slaves`. */
  void writeListedStateRequest(const std::vector<std::uint16_t>& slaves, EcState state);

  /**
   * True when every slave in `slaves` has masked ESM == `expected_state`, no ESM error bit, and a
   * zero AL-status code. An empty list is vacuously true. Call `refreshStates()` first if the
   * cache may be stale. The per-slave-subset analogue of `allSlavesInState`.
   */
  bool listedSlavesInState(const std::vector<std::uint16_t>& slaves, EcState expected_state) const;

  /** PRE_OP → SAFE_OP after `configMap()` (never INIT — that invalidates mapped SM2/PDO). */
  bool ensureSafeOperational(int timeout_us_per_step = kTimeoutState * 4);

  /**
   * Walk only the listed slaves PRE_OP → SAFE_OP (they must already be in PRE_OP after
   * `configMap()`), exchanging process data while waiting so DC-strict drives see valid input
   * frames during the transition. Slaves not in the list are left untouched. Empty list is a
   * no-op that returns true.
   */
  bool ensureListedSafeOperational(const std::vector<std::uint16_t>& slaves,
                                   int timeout_us = kTimeoutState * 4);

  /**
   * Second-stage bus walk-down, executed *after* the RT cyclic thread has driven the network
   * OP → SAFE_OP under its own DC phase-locked PDO. Disables SYNC0 on every DC-capable slave,
   * then walks SAFE_OP → PRE_OP → INIT. Never fatal on its own; failures are reported in the
   * return value (the subsequent `close()` still forces INIT and tears the socket down).
   */
  BusShutdownResult shutdownBus(int al_state_timeout_ms = 2000);

  /**
   * Disable SYNC0 on every DC-capable slave. Call as soon as the RT cyclic thread stops while
   * slaves are still at SAFE_OP — before any slow post-join SDO work. Idempotent.
   */
  void disableSync0();

  int sendProcessData();
  int receiveProcessData(int timeout_us);

  /**
   * Re-read every slave's AL state into the cache (SOEM `ec_readstate` / LXEC `refresh_states`).
   * Call before `slaveInfo()` / `allSlavesInState()` when the cache may be stale.
   */
  void refreshStates();

  /**
   * Configured-address ESC register read. Addresses the slave by its configured station address
   * and reads `len` bytes at register offset `ado`. `data` is in host byte order. Returns the
   * working counter (`> 0` on success). Must only be called while open; never from the RT path.
   */
  int readRegister(std::uint16_t slave_index, std::uint16_t ado, void* data, std::uint16_t len,
                   int timeout_us = 20000);

  /**
   * Read a slave's DL-status (0x0110) and decode it into an active-port bitmask: bit N set means
   * port N has an established link (ETG.1000 decode `(dl & 0x0300<<2N) == 0x0200<<2N`). When
   * `responding` is non-null it is set to whether the slave answered (working counter > 0); a
   * non-responding slave returns mask 0. Configured-address access; never call from the RT path.
   */
  std::uint8_t portLinkMask(std::uint16_t slave_index, bool* responding, int timeout_us = 20000);

  /**
   * CoE SDO download. `complete_access` selects complete-access transfer. When `abort_out` is
   * non-null it receives the SDO abort code (0 == none) captured synchronously. Returns the
   * working counter (`> 0` on success).
   */
  int writeSdo(std::uint16_t slave_index, std::uint16_t index, std::uint8_t sub,
               bool complete_access, const void* data, int size,
               std::int32_t* abort_out = nullptr);

  /**
   * CoE SDO upload. `*size` is in/out: pass buffer capacity, receive bytes read. When `abort_out`
   * is non-null it receives the SDO abort code (0 == none). Returns the working counter.
   */
  int readSdo(std::uint16_t slave_index, std::uint16_t index, std::uint8_t sub,
              bool complete_access, void* data, int* size, std::int32_t* abort_out = nullptr);

  /** Drain the backend's CoE/SoE error queue so a stale abort cannot masquerade as a later read. */
  void drainErrors();

  int slaveCount() const;

  /** Expected working counter for the whole mapped group. */
  int expectedWkc() const;

  /**
   * Expected working counter for just the listed (1-based) slaves, computed with the active
   * backend's process-data addressing model: SOEM uses one LRW datagram (outputs count twice),
   * LXEC uses split LWR + LRD (outputs count once). Used by the OP-subset WKC watchdog floor.
   */
  int expectedWkcForSlaves(const std::vector<std::uint16_t>& slaves) const;

  void close();

  bool isOpen() const;

  /** Backend-neutral snapshot of slave `index` (by value; `valid==false` if out of range). */
  SlaveInfo slaveInfo(std::uint16_t index) const;

  /** Hot-path process-image pointers for slave `index` (live into the IOmap). */
  PdoImage pdoImage(std::uint16_t index) const;

  /** Group-level process-image geometry. */
  ProcessImageInfo processImage() const;

  /** Distributed-clock reference system time of the last process-data exchange, in ns. */
  std::uint64_t dcTimeNs() const;

  /** True when the bus is running distributed clocks (any DC-capable slave configured). */
  bool busHasDc() const;

  // Floating-seat session expiry (UTC epoch) set by init(). 0 = not a floating-seat session.
  // Read by EcNetwork after start() to arm the deadline watcher thread.
  std::time_t licenseSessionExpiryUnix() const noexcept { return session_expiry_unix_; }

private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
  std::string init_error_;        // set by init() on a license-gate denial; see initError()
  std::time_t session_expiry_unix_{0};  // from the floating-seat check(); 0 if not floating
};

}  // namespace ecmaster
