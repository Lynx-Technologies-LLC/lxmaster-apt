#pragma once

#include <string>
#include <vector>

namespace ecnet {

/**
 * One slave that stopped responding when the bus fault was diagnosed.
 * `index` is the 1-based bus position; `name` is the SII/ENI device name.
 */
struct LostSlave {
  int index{0};
  std::string name;
};

/**
 * Structured description of a cyclic-bus fault, built when the cycle-health watchdog trips
 * (see `NetworkConfig::watchdog_low_wkc_cycles`). Delivered to the
 * application through the optional `NetworkConfig::on_bus_fault` callback and also used by
 * lxmaster to render the default `lastError()` / `reportDeviceStatus()` text.
 *
 * The break point is reconstructed from the standard DL-status register (0x0110): the
 * still-responding slave whose previously-active port lost its link is the upstream side of
 * the cable break, and `lost_slaves` are the devices that went silent behind it.
 */
struct BusFault {
  /** True when a fault was detected and this struct is meaningful. */
  bool occurred{false};
  /** 1-based bus index of the still-responding slave whose downstream port dropped its link.
   *  0 means no responder showed a dropped port (break at the master / first link). */
  int break_slave{0};
  /** SII/ENI name of `break_slave` (empty when `break_slave == 0`). */
  std::string break_slave_name;
  /** ESC port index (0-3) on `break_slave` whose link dropped, or -1 if unknown. */
  int break_port{-1};
  /** Slaves that stopped responding (downstream of the break). */
  std::vector<LostSlave> lost_slaves;
  /** Work counter observed on the tripping cycle and the expected value. */
  int wkc{0};
  int expected_wkc{0};
  /** Per-direction working counters of the last cycle (backends with split LWR/LRD only). */
  bool wkc_split_valid{false};
  int output_wkc{0};
  int expected_output_wkc{0};
  int input_wkc{0};
  int expected_input_wkc{0};
  /** Responding slaves that are no longer in OP (state, AL status code). */
  struct NotOpSlave {
    int index{0};
    std::string name;
    int state{0};
    int al_code{0};
  };
  std::vector<NotOpSlave> not_op_slaves;
  /** Pre-rendered human-readable summary so simple apps can just print it. */
  std::string description;

  /** True when the evidence points at a physical link: a slave went silent or a port dropped. */
  bool isLinkBreak() const noexcept { return !lost_slaves.empty() || break_slave != 0; }
};

/** Render `BusFault::description` from the structured fields. Only blames cabling when a slave
 *  stopped answering or a port lost its link; otherwise names what the WKC split / AL states show. */
std::string describeBusFault(const BusFault& fault);

}  // namespace ecnet
