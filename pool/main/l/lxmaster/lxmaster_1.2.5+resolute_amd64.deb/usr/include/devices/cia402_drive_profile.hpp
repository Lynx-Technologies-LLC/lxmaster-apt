#pragma once

#include "devices/cia402_fsm.hpp"
#include "devices/device_profile.hpp"
#include "devices/motion_profile.hpp"
#include "devices/process_image.hpp"
#include "devices/sync_mode.hpp"

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace ecdev {

struct ProfileSelectionInput;

/** Build a CiA402DriveProfile from the selection input (op-mode / fault-policy flags). Bind it to a
 *  device identity with `makeIdentityProfileFactory`. */
std::unique_ptr<IDeviceProfile> makeCiA402DriveProfile(const ProfileSelectionInput& in);

/** What a CiA402 drive looked like while it was asked to enable but never got there. */
struct EnableAttemptSnapshot {
  std::uint16_t slave{0};
  std::uint64_t attempt_cycles{0};      ///< Cycles with enable requested and not yet enabled.
  std::uint16_t pdo_statusword{0};      ///< Statusword from the TxPDO on the last such cycle.
  std::uint16_t controlword{0};         ///< Last controlword written on such a cycle.
  std::uint64_t cw_hold_cycles{0};      ///< Consecutive cycles that controlword was held.
  bool have_sdo_statusword{false};
  std::uint32_t sdo_statusword{0};      ///< 0x6041 read over SDO after the run.
  bool have_error_code{false};
  std::uint32_t error_code{0};          ///< 0x603F.
  bool have_error_register{false};
  std::uint32_t error_register{0};      ///< 0x1001.
  bool have_mode_display{false};
  std::uint32_t mode_display{0};        ///< 0x6061.
  std::vector<std::uint8_t> out_bytes;  ///< Raw output image on the last such cycle.
  std::vector<std::uint8_t> in_bytes;   ///< Raw input image on the last such cycle.
};

/** Decoded DS402 state name for a statusword ("Switch On Disabled", ...). */
const char* cia402StateName(std::uint16_t statusword) noexcept;

/** Render the enable-failure block. `image` (may be null) supplies the mapped entry layout; each
 *  entry is decoded from the snapshot bytes and objects mapped more than once are flagged. */
std::string formatEnableFailureReport(const EnableAttemptSnapshot& snap, const ProcessImage* image);

/**
 * CiA 402 (CANopen-over-EtherCAT) servo-drive profile. Plugs onto a {@link GenericEniDevice} and
 * provides the drive-class behaviour that used to live in `CiA402Device`:
 *   - PreOP validation + operating-mode setup: it confirms the cyclic objects it drives
 *     (controlword/statusword/target+actual position) are present in the ENI PDO mapping and fails
 *     otherwise. It makes NO configuration assumptions ("ENI is law") with ONE deliberate
 *     exception: the operating mode 0x6060, which is application/axis intent rather than bus wiring,
 *     so the profile writes it (from `Config::op_mode`) and reads it back to confirm at PreOP. SM
 *     sync-mode (0x1C32/0x1C33), the 0x60C2 interpolation time, and any vendor tuning still arrive
 *     as ENI CoE InitCmds replayed by {@link GenericEniDevice}; DC SYNC0 is activated by the master
 *     from the ENI <DC>; the generic 0x1C1x/0x16xx PDO assignment is done by {@link GenericEniDevice}.
 *   - DS402 controlword state machine ({@link CiA402Fsm}) on the RT cyclic path.
 *   - A lock-free snapshot so application threads (through the `Axis` facade / IMotionProfile)
 *     read position/statusword and command targets without touching PDO bytes.
 *
 * It implements {@link IMotionProfile}, which is the only thing the `Axis` facade depends on, so
 * the controlword/statusword stay hidden inside this profile.
 *
 * Extending it: this class is intentionally NOT `final`. To add vendor/extra PDO variables (objects
 * the ENI maps beyond the standard CiA402 set), subclass it, override the relevant lifecycle method
 * (typically `readInputs`, and optionally `resolveTopology`/`configurePreOp`), and CHAIN to the base
 * (`CiA402DriveProfile::readInputs(...)`) before doing your own work. Resolve your extra objects with
 * `ProcessImage::resolve(index, sub)` and publish them to application threads through your own
 * lock-free state (atomics). `Axis` keeps working unchanged because the subclass inherits this
 * profile's `asMotion()`. This mirrors the {@link GenericIoProfile} -> {@link CiA401IoProfile}
 * precedent. The application reaches the subclass via `ecfacade::DeviceFacade::deviceProfile()`.
 */
class CiA402DriveProfile : public IDeviceProfile, public IMotionProfile {
public:
  /** Cyclic operation mode this profile drives. CSP commands target position (0x607A); CSV
   * commands target velocity (0x60FF); CST commands target torque (0x6071, INT16). The ENI/ESI
   * must map the matching object and set the drive's modes-of-operation (0x6060) accordingly --
   * the profile only validates the mapping. The per-mode cyclic facts live in the OpModeTraits
   * table in cia402_drive_profile.cpp. */
  using OpMode = DriveOpMode;

  /**
   * Per-instance configuration for a `CiA402DriveProfile`. Passed at construction and consumed
   * by the profile lifecycle; some fields may be overridden at runtime via `setOperatingMode()` /
   * `setAutoFaultRecover()` between `prepare()` and `start()`.
   */
  struct Config {
    /** When true (default) the DS402 state-machine (`CiA402Fsm`) runs each cyclic iteration and
     *  drives the controlword through the standard enable/disable/fault-reset sequence. Set false
     *  only for diagnostic profiling where you want to write the controlword manually. */
    bool enable_fsm{true};
    /** When the axis is enabled and no `moveTo()` has been issued yet, command the drive to hold
     *  its actual position at enable time (CSP: target = actualPosition). Prevents unintended
     *  motion when the application enables the drive before setting a target. */
    bool hold_actual_position{true};
    /** When true the FSM automatically pulses a fault-reset and returns to enabling after a
     *  mid-run trip (any fault after Operation Enabled has been reached). When false (default)
     *  faults are terminal — the profile requests a cyclic stop and the application must handle
     *  recovery. */
    bool auto_fault_reset_and_recover{false};
    /** When a drive enters OPERATIONAL already in the Fault state (a residual fault carried over
     *  from a prior run, before this run has ever reached Operation Enabled), automatically pulse
     *  a bounded fault-reset and continue the enable sequence instead of treating it as a terminal
     *  stop. A fault that appears *after* the drive reaches Operation Enabled is always terminal
     *  regardless of this flag. On by default. */
    bool startup_fault_autoreset{true};
    /** When true (default), the shutdown sequence waits for the drive to reach Switch-On Disabled
     *  (or Fault) before proceeding to the AL state walk-down. Set false to skip the wait, which
     *  can speed up shutdown on drives that do not de-energise quickly. */
    bool shutdown_require_switch_on_disabled{true};
    /** Number of RT cycles the startup fault-reset window remains active (see
     *  `startup_fault_autoreset`). After this many cycles without reaching Operation Enabled the
     *  reset attempt is abandoned and the fault is treated as terminal. */
    int fault_reset_arm_cycles{50};
    /** Initial cyclic operating mode (CSP/CSV/CST). Seeded into the drive at PRE_OP via SDO and
     *  used as the default when 0x6060 is not mapped in the RxPDO. Override with
     *  `setOperatingMode()` between `prepare()` and `start()`. */
    OpMode op_mode{OpMode::Csp};
  };

  explicit CiA402DriveProfile(Config cfg);

  const char* profileName() const override { return "CiA402-drive"; }
  IMotionProfile* asMotion() noexcept override { return this; }

  /* ---- IDeviceProfile ---- */
  std::string configurePreOp(ISlaveServices& svc, ProcessImage& image) override;
  std::string prepareSafeOp(ISlaveServices& svc, ProcessImage& image) override;
  void writeOutputs(ProcessImage& image, std::uint64_t cycle_count) override;
  void readInputs(const ProcessImage& image, bool wkc_valid, bool operational) override;
  void primeOutputs(ProcessImage& image) override;
  void prepareShutdown() override { out_.request_disable.store(true, std::memory_order_release); }
  bool readyForShutdown() const noexcept override { return isShutdownRestingState(); }
  bool requiresMotionShutdown() const noexcept override { return cfg_.enable_fsm; }
  bool requiresAlShutdown() const noexcept override {
    return cfg_.enable_fsm && cfg_.shutdown_require_switch_on_disabled;
  }
  bool hasLeftOperationEnabled() const noexcept override;
  bool readyForAlShutdown() const noexcept override;
  bool cyclicStopRequested() const noexcept override {
    return cyclic_stop_requested_.load(std::memory_order_acquire);
  }
  std::string cyclicStopReason() const override;
  std::uint16_t lastStatusWordForDiagnostics() const noexcept override { return statusword(); }
  void captureExitDiagnostics(ISlaveServices& svc) override;
  /** "Drive never reached Operation Enabled" report (empty when it did, or was never asked to). */
  std::string exitReport() const override { return enable_report_; }

  /* ---- IMotionProfile mode + fault configuration ---- */
  /** Choose the operating mode. Pre-start this seeds the initial mode; while running it also
   * switches live -- when the ENI maps 0x6060 into the RxPDO the profile writes out_.desired_mode
   * every cycle, so CSP/CSV/CST switch while OPERATIONAL. The atomic store is RT-safe; cfg_.op_mode
   * (used only by the legacy no-0x6060 path, which is fixed at PRE_OP) is not read cyclically in
   * PDO mode. */
  void setOperatingMode(DriveOpMode mode) noexcept override {
    cfg_.op_mode = mode;
    out_.desired_mode.store(mode, std::memory_order_release);
  }
  void setAutoFaultRecover(bool enable) noexcept override {
    cfg_.auto_fault_reset_and_recover = enable;
  }

  /* ---- IMotionProfile (application-thread API behind the Axis facade) ---- */
  void setTargetPosition(std::int32_t counts) noexcept override {
    out_.target_position.store(counts, std::memory_order_release);
    out_.have_target_position.store(true, std::memory_order_release);
  }
  /** CSV target velocity in counts/s. Has its own command slot (0x60FF) so a CSP position target
   * and a CSV velocity target can coexist for bumpless live mode switching; only the object
   * matching the active op-mode is honoured by the drive. */
  void setTargetVelocity(std::int32_t counts_per_sec) noexcept override {
    out_.target_velocity.store(counts_per_sec, std::memory_order_release);
  }
  /** CST target torque in per-mille of rated torque. Has its own command slot (0x6071) so it can
   * coexist with position/velocity targets for bumpless live mode switching; only the object
   * matching the active op-mode is honoured by the drive. */
  void setTargetTorque(std::int32_t per_mille_rated) noexcept override {
    out_.target_torque.store(per_mille_rated, std::memory_order_release);
  }
  void requestEnable() noexcept override {
    out_.request_disable.store(false, std::memory_order_release);
  }
  void requestDisable() noexcept override {
    out_.request_disable.store(true, std::memory_order_release);
  }
  void requestFaultReset() noexcept override {
    out_.request_fault_reset.store(true, std::memory_order_release);
  }
  std::int32_t actualPosition() const noexcept override {
    return in_.actual_position.load(std::memory_order_acquire);
  }
  std::int32_t targetPosition() const noexcept override {
    return out_.target_position.load(std::memory_order_acquire);
  }
  std::int32_t actualVelocity() const noexcept override {
    return in_.actual_velocity.load(std::memory_order_acquire);
  }
  std::int32_t actualTorque() const noexcept override {
    return in_.actual_torque.load(std::memory_order_acquire);
  }
  std::int32_t modeDisplay() const noexcept override {
    return in_.mode_display.load(std::memory_order_acquire);
  }
  bool hasModeDisplay() const noexcept override {
    return mode_display_live_.load(std::memory_order_acquire);
  }
  std::uint16_t statusword() const noexcept override {
    return in_.statusword.load(std::memory_order_acquire);
  }
  bool isOperationEnabled() const noexcept override {
    return (statusword() & CiA402Fsm::kStateMask) == CiA402Fsm::kStateOperationEnabled;
  }
  bool isFault() const noexcept override {
    return (statusword() & CiA402Fsm::kStatusFaultBit) != 0;
  }

private:
  bool isShutdownRestingState() const noexcept {
    const std::uint16_t st = statusword() & CiA402Fsm::kStateMask;
    return st == CiA402Fsm::kStateReadyToSwitchOn || st == CiA402Fsm::kStateSwitchOnDisabled ||
           isFault();
  }

  Config cfg_;
  CiA402Fsm fsm_;

  /* Resolved process-image handles (set in configurePreOp / first cycle). */
  PdoEntryRef cw_ref_{};
  PdoEntryRef sw_ref_{};
  /** The single cyclic target object for the active op-mode (0x607A / 0x60FF / 0x6071), chosen
   * from the OpModeTraits table at resolve time. Used only on the legacy (no 0x6060 in PDO) path. */
  PdoEntryRef target_ref_{};
  /** Modes of operation (0x6060) in the RxPDO. When valid the profile is in "PDO mode control":
   * it writes the desired mode every cycle and can switch CSP/CSV/CST live. When invalid it falls
   * back to the legacy single-target path with the mode set once via SDO at PRE_OP. */
  PdoEntryRef mode_ref_{};
  /** Per-mode command targets, resolved independently so all three can be written each cycle (the
   * active one carries the command, the others a neutral value) for bumpless live switching. */
  PdoEntryRef target_pos_ref_{};
  PdoEntryRef target_vel_ref_{};
  PdoEntryRef target_torque_ref_{};
  PdoEntryRef actual_pos_ref_{};
  PdoEntryRef actual_vel_ref_{};
  PdoEntryRef actual_torque_ref_{};
  PdoEntryRef mode_display_ref_{};
  std::atomic<bool> mode_display_live_{false};
  bool refs_resolved_{false};

  std::atomic<bool> cyclic_stop_requested_{false};
  /* Why the cyclic stop was requested, latched by `readInputs` on the RT thread. The
   * human-readable string is built off the RT thread by `cyclicStopReason()` from this + the
   * atomic statusword snapshot + `exit_error_603f_`, so the RT path never allocates. */
  enum class MotionStopKind : std::uint8_t { None, FaultInOp, ResidualStartupFault };
  std::atomic<MotionStopKind> motion_stop_kind_{MotionStopKind::None};
  /** CiA402 error code 0x603F read after RT join by `captureExitDiagnostics` (off-RT). */
  std::atomic<std::uint16_t> exit_error_603f_{0};
  bool motion_fault_latched_{false};
  /* Startup fault-reset window state (see Config::startup_fault_autoreset). `ever_operation_enabled_`
   * flips true the first time the drive reaches Operation Enabled this run; after that any fault is a
   * terminal mid-run trip. `startup_reset_cycles_` bounds the pre-enable reset window;
   * `startup_reset_active_` is set by readInputs and consumed by writeOutputs to pulse bit 7. */
  bool ever_operation_enabled_{false};
  int startup_reset_cycles_{0};
  bool startup_reset_active_{false};

  /* Enable-attempt snapshot, written by writeOutputs on the RT thread while enable is requested
   * and the drive has not yet reached Operation Enabled; frozen once it does or a disable is
   * requested. Read by captureExitDiagnostics after the RT join. Fixed storage, no allocation. */
  void noteEnableAttempt(const ProcessImage& image, std::uint16_t controlword) noexcept;
  static constexpr std::size_t kSnapBytes = 64;
  const ProcessImage* diag_image_{nullptr};
  std::uint64_t enable_attempt_cycles_{0};
  std::uint16_t enable_last_cw_{0};
  std::uint64_t enable_cw_hold_cycles_{0};
  std::uint16_t enable_last_sw_{0};
  std::uint8_t enable_out_snap_[kSnapBytes]{};
  std::uint8_t enable_in_snap_[kSnapBytes]{};
  std::size_t enable_out_len_{0};
  std::size_t enable_in_len_{0};
  std::string enable_report_;

  struct alignas(64) InputSnapshot {
    std::atomic<std::int32_t> actual_position{0};
    std::atomic<std::int32_t> actual_velocity{0};
    std::atomic<std::int32_t> actual_torque{0};
    std::atomic<std::int32_t> mode_display{kModeDisplayUnknown};
    std::atomic<std::uint16_t> statusword{0};
  };
  struct alignas(64) OutputSnapshot {
    std::atomic<std::int32_t> target_position{0};
    std::atomic<std::int32_t> target_velocity{0};
    std::atomic<std::int32_t> target_torque{0};
    std::atomic<bool> have_target_position{false};
    std::atomic<bool> request_disable{false};
    std::atomic<bool> request_fault_reset{false};
    /** Live operating-mode request (PDO mode control). Seeded from Config::op_mode in the ctor. */
    std::atomic<DriveOpMode> desired_mode{DriveOpMode::Csp};
  };
  InputSnapshot in_;
  OutputSnapshot out_;

  void resolveRefs(const ProcessImage& image);
};

}  // namespace ecdev
