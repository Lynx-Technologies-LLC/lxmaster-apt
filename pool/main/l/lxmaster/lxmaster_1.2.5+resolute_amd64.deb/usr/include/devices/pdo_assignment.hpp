#pragma once

#include "eni/eni_model.hpp"

#include <cstdint>
#include <string>
#include <vector>

namespace ecdev {

class ISlaveServices;

/**
 * Generic, ENI-driven CoE PDO assignment. Programs each data SyncManager's assignment object
 * (0x1C1x) and the contained mapping objects (0x16xx RxPDO / 0x1Axx TxPDO) to EXACTLY what the
 * ENI `<Slave>` describes -- for any CoE device, not just CiA402 drives. This replaces the
 * hardcoded 0x1600/0x1A00 remap that used to live in `CiA402Device`/`CiA402PdoCodec`.
 *
 * It is applied generically by {@link GenericEniDevice} in the PreOP PO2SO hook, before the
 * device profile's own configuration. The backend's config-map step then computes the SM lengths, FMMUs,
 * and the logical process image from the assignment we just programmed -- so the byte offsets in
 * the {@link ProcessImage} (also derived from the same ENI PDOs) line up with the live IOmap.
 *
 * Reaches the master only through {@link ISlaveServices} (no backend types here).
 */
class PdoAssignment {
public:
  /** Build the assignment plan from an ENI slave (its sync managers + rx/tx PDOs). */
  static PdoAssignment fromSlaveConfig(const eni::SlaveConfig& slave);

  /** True when there is at least one mapped data SM to program. */
  bool empty() const noexcept { return groups_.empty(); }

  /** Program the assignment over CoE. Returns the aggregate working counter. */
  int apply(ISlaveServices& svc) const;
  /** Read back assignment + mapping counts to confirm the plan is active. */
  bool verify(ISlaveServices& svc) const;
  /** Aggregate WKC expected from `apply()` when every SDO succeeds once. */
  int expectedWkc() const noexcept { return expected_wkc_; }
  /** Non-empty when the ENI cannot be programmed as described (e.g. one PDO index assigned
   *  twice); the slave must not be configured from this plan. */
  const std::string& error() const noexcept { return error_; }

  /**
   * Read the layout the slave actually has now (0x1C1x assignments, then every assigned mapping
   * object's entries) and compare it with the ENI: a PDO index assigned twice, or a byte size
   * that differs from what the ENI PDOs for that SyncManager map, is returned as an error. CoE InitCmds
   * replayed after `apply()` can rewrite the assignment, so call this after the full PS replay.
   * Objects that cannot be read are skipped (returns empty: nothing provably wrong).
   */
  std::string checkLiveLayout(ISlaveServices& svc) const;

  struct PdoPlan {
    std::uint16_t index{0};                 ///< Mapping object index (0x16xx / 0x1Axx).
    std::vector<std::uint32_t> entries;     ///< Packed mapping words (index<<16|sub<<8|bitlen).
  };
  struct SmGroup {
    std::uint16_t assignment_index{0};      ///< 0x1C10 + sm_index.
    std::uint16_t eni_sm_bytes{0};          ///< ENI SyncManager DefaultSize (0 = not declared).
    std::vector<PdoPlan> pdos;
  };

private:
  int slave_position_{0};
  std::vector<SmGroup> groups_;
  int expected_wkc_{0};
  std::string error_;
};

}  // namespace ecdev
